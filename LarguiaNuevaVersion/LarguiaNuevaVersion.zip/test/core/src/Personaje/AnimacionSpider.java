package Personaje;

import Auxiliar.Auxiliar;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class AnimacionSpider {
	
	public final static int estadoAnimacionIzquierda=0;
	public final static int estadoAnimacionDerecha=1;
	public final static int estadoAnimacionArriba=2;
	public final static int estadoAnimacionAbajo=3;
	public final static int estadoMuere = 4;
	public static float tiempoFrameMovimiento=0.08f;
	public static float tiempoFrameMuere;
	
	protected int estado;
	protected float duracionAnimacionActual;
	protected Animation animacionActual; 
	protected TextureRegion arrayTextures[][];
	protected Texture textura;
	protected int altoFrame;
	protected int anchoFrame;
	protected Spider spider;
	
	protected Animation andaDerecha;
	protected Animation andaIzquierda;
	protected Animation andaArriba;
	protected Animation andaAbajo;
	protected Animation muere;
	
	
	public AnimacionSpider(Spider spider,int anFrame,int alFrame){
		this.spider = spider;
		duracionAnimacionActual = 0;
		altoFrame = alFrame;
		anchoFrame = anFrame;
		estado = estadoAnimacionAbajo;
		
		TextureRegion tRegionAnimacion= new TextureRegion(textura);
		arrayTextures=tRegionAnimacion.split(textura, anchoFrame, altoFrame);
		//andar
		
		
				TextureRegion[] animacionAndarArriba = Auxiliar.getFilaArrayTextRegion(0,10,arrayTextures);
				TextureRegion[] animacionAndarAbajo = Auxiliar.getFilaArrayTextRegion(2,10,arrayTextures);
				TextureRegion[] animacionAndarDerecha = Auxiliar.getFilaArrayTextRegion(3,10,arrayTextures);
				TextureRegion[] animacionAndarIzquierda = Auxiliar.getFilaArrayTextRegion(1,10,arrayTextures);
				
				TextureRegion[] animacionMuere = Auxiliar.getFilaArrayTextRegion(4,4,arrayTextures);
		
				
				andaArriba=new Animation(tiempoFrameMovimiento,animacionAndarArriba);
				andaAbajo=new Animation(tiempoFrameMovimiento,animacionAndarAbajo);
				andaDerecha=new Animation(tiempoFrameMovimiento,animacionAndarDerecha);
				andaIzquierda=new Animation(tiempoFrameMovimiento,animacionAndarIzquierda);
				
				andaIzquierda=new Animation(tiempoFrameMuere,animacionMuere);
	}
	
}