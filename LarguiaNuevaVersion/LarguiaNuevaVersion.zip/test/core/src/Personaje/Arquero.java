package Personaje;



import Auxiliar.Punto;
import Larguia.ControladorSonido;
import Larguia.PantallaJuego;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;


public class Arquero extends Heroe {
	
	//Flecha flecha;
	public final static int offsetArriba = 7;
	public final static int offsetAbajo = 12;
	public final static int radioDisparo = anchoFrame/2;
	private int damageFlecha = 100;
	public final static int frameDisparo = 11;
	
	
	
	
	public Arquero(float x,float y,String nombre,int nFoto){
		
		
		
		//ancho y alto del frame
		super(x+anchoFrame/2,y+altoFrame/2 - offsetArriba,nombre,nFoto);
		
		velocidadMovimiento = 100;
		super.textura = new Texture("images/"+nFoto+".png");		
		animacion = new AnimacionArquero(this);
		
		anchoReal = 40;
		altoReal = 50;
		rectangle = new Rectangle(x-anchoFrame/2,y-altoFrame/2 + offsetArriba, anchoReal, altoReal);
	}
	
	
	
	public void actualizarAnimacionSerializada(){
		float duracionAnimacion = animacion.getDuracion();
		int columna= 0;
		if(animacion.isAnimacionMovimientoOCasteo()){
			duracionAnimacion = duracionAnimacion/(animacion.tiempoFrameMovimiento*9);
			columna = (int)(duracionAnimacion / animacion.tiempoFrameMovimiento);
			columna = columna % 9;
			
		}else if(!animacion.isAnimacionMovimientoOCasteo()){
			 columna = animacion.getAnimacionActual().getKeyFrameIndex(duracionAnimacion);
		}
		int fila = -1;
		if(animacion.isAnimacionMovimientoAbajo()){
			fila = 10;
		}else if(animacion.isAnimacionMovimientoArriba()){
			fila = 8;
		}else if(animacion.isAnimacionMovimientoDerecha()){
			fila = 11;
		}else if(animacion.isAnimacionMovimientoIzquierda()){
			fila = 9;
		}else if(animacion.isAnimacionAccion1Arriba()){
			fila = 16;
		}else if(animacion.isAnimacionAccion1Abajo()){
			fila = 18;
		}else if(animacion.isAnimacionAccion1Derecha()){
			fila = 19;
		}else if(animacion.isAnimacionAccion1Izquierda()){
			fila = 17;
		}else if(animacion.isAnimacionMorir()){
			fila = 20;
		}
		//System.out.println("fila "+fila+"columna "+columna);
		serializada.setFila(fila);
		serializada.setColumna(columna);
		serializada.setVida(this.vida);
		
		
	}
	
	
	
	/**
	 * Esta hecho para que si termina accion1 (frame11 de accion1) dispare flecha
	 * */
public boolean isDisparaFlecha(){
		
		boolean animacionDisparo = animacion.isAnimacionAccion1();
		boolean isFrameDisparo = frameDisparo == animacion.getAnimacionActual().getKeyFrameIndex(animacion.getDuracion());
		
		boolean dispara = animacionDisparo && isFrameDisparo && primeraVez;
		//boolean valor = false;
	/***	
	**/
		
		
		
		return dispara;
	}
	
	
	public static double anguloVectores(double x1, double y1, double x2, double y2){
		
		double u1 = x1;
		double u2 = y1;
		double v1 = x2 ;
		double v2 = y2;
		double numerador = (u1 * v1) + (u2 * v2);
		double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
				* Math.sqrt((v1 * v1) + (v2 * v2));
		
		double coseno = numerador / denominador;
		double angulo = Math.acos(coseno);
		
		return angulo;
		
	}
	public Punto getPosicionInicialFlechaArr(){
		Punto punto;
		double u1 = x+3;
		double u2 = 0;
		double v1 = clickDerechoX - x;
		double v2 = clickDerechoY - y;
		double angulo = anguloVectores(u1, u2, v1, v2);
		//System.out.println("metodo angulo"+angulo*180/Math.PI);
		double ladoX = Math.cos(angulo)*radioDisparo;
		double ladoY = Math.sin(angulo)*radioDisparo;
		double posX = x + ladoX;
		double posY = y + ladoY;
		punto = new Punto((float)posX,(float)posY);
		return punto;
	}
	public Punto getPosicionInicialFlechaAbaj(){
		Punto punto;
		double u1 = x-3;
		double u2 = 0;
		double v1 = clickDerechoX - x;
		double v2 = +clickDerechoY - y;
		double angulo = anguloVectores(u1, u2, v1, v2);
		
		double ladoX = Math.cos(angulo)*radioDisparo;
		double ladoY = Math.sin(angulo)*radioDisparo;
		double posX = x + ladoX;
		double posY = y - ladoY;
		punto = new Punto((float)posX,(float)posY);
		return punto;
	}
	public Punto getPosicionInicialFlechaDer(){
		Punto punto;
		double angulo = anguloVectores(0,y-3,x-clickDerechoX,y-clickDerechoY);
		
		double ladoY = Math.cos(angulo)*radioDisparo;
		double ladoX = Math.sin(angulo)*radioDisparo;
		double posX = x + ladoX;
		double posY = y - ladoY;
		punto = new Punto((float)posX,(float)posY);
		return punto;
		
	}
	public Punto getPosicionInicialFlechaIzq(){
		Punto punto;
		double angulo = anguloVectores(0,y+3,clickDerechoX-x,clickDerechoY-y);
		double ladoY = Math.cos(angulo)*radioDisparo;
		double ladoX = Math.sin(angulo)*radioDisparo;
		//if(angulo<)
		double posX = x - ladoX;
		double posY = y + ladoY;
		if(ladoY < 0)System.out.println("lado y menor que cero");
		if(ladoX < 0 )System.out.println("lado x menor que cero");
		if(ladoY > 0)System.out.println("lado y mayor que cero");
		if(ladoX > 0 )System.out.println("lado x mayor que cero");
		punto = new Punto((float)posX,(float)posY);
		return punto;
	}
	
	public void disparar(PantallaJuego pantalla){
			
			float xInicial=0, yInicial=0;
			Punto punto;
			double angulo=0;
			Flecha flecha = null;
			double pos[];
			switch(animacion.getEstado()){
			//Flecha(Arquero heroe,float objX,float objY, int tipo, int damage,float angulo)
			case AnimacionHeroe.estadoAnimacionAccion1Izq:
				
				punto = getPosicionInicialFlechaIzq();
				xInicial = punto.getX();
				yInicial = punto.getY();
				angulo =  getAnguloFlechaIzq();
				flecha = new Flecha(this.nombre,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionIzquierda,damageFlecha,(float)angulo,pantalla);
				pantalla.getJuego().getCliente().enviarFlechaSerializada(this,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionIzquierda,damageFlecha,(float)angulo);
				
				//System.out.println("el punto de rotacion es "+flecha.getSprite().getOriginX()+","+flecha.getSprite().getOriginY());
				pantalla.addFlecha(flecha);
				pantalla.getJuego().reproducirDisparo();
				break;
			case AnimacionHeroe.estadoAnimacionAccion1Der:
				
				punto  = getPosicionInicialFlechaDer();
				xInicial = punto.getX();
				yInicial = punto.getY();
				angulo = getAnguloFlechaDer();
				flecha = new Flecha(this.nombre,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionDerecha,damageFlecha,(float)angulo,pantalla);
				pantalla.getJuego().getCliente().enviarFlechaSerializada(this,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionDerecha,damageFlecha,(float)angulo);

				pantalla.addFlecha(flecha);
				pantalla.getJuego().reproducirDisparo();
				break;
			case AnimacionHeroe.estadoAnimacionAccion1Arr:
				
				punto = getPosicionInicialFlechaArr();                
				xInicial = punto.getX();
				yInicial = punto.getY();
				angulo = getAnguloFlechaArr();
				flecha = new Flecha(this.nombre,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionArriba,damageFlecha,(float)angulo,pantalla);
				pantalla.getJuego().getCliente().enviarFlechaSerializada(this,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionArriba,damageFlecha,(float)angulo);

				pantalla.addFlecha(flecha);
				pantalla.getJuego().reproducirDisparo();
				break;
			case AnimacionHeroe.estadoAnimacionAccion1Abaj:
				
				punto = getPosicionInicialFlechaAbaj();
				xInicial = punto.getX();
				yInicial = punto.getY();
				angulo = getAnguloFlechaAbaj();
				flecha = new Flecha(this.nombre,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionAbajo,damageFlecha,(float)angulo,pantalla);
				pantalla.getJuego().getCliente().enviarFlechaSerializada(this,xInicial,yInicial+Flecha.altoFotograma/2,clickDerechoX,clickDerechoY,Flecha.direccionAbajo,damageFlecha,(float)angulo);

				pantalla.addFlecha(flecha);
				pantalla.getJuego().reproducirDisparo();
				break;
			}
			//flecha.setPosicion(xInicial, yInicial);
			primeraVez = false;
		
		
		
		//flecha.setPos();
	}
	
	public double getAnguloFlechaAbaj(){
		double u1 = x-3;
		double u2 = 0;
		double v1 = clickDerechoX - x;
		double v2 = clickDerechoY - y;
		double numerador = (u1 * v1) + (u2 * v2);
		double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
				* Math.sqrt((v1 * v1) + (v2 * v2));

		double coseno = numerador / denominador;
		//double angulo = Math.acos(coseno);
		
	
		double angulo = (Math.PI)- Math.acos(coseno);
		angulo = (angulo * 180 /Math.PI) + 180;
		//System.out.println("angulo real "+angulo);
		return angulo;
		
	}
	public double getAnguloFlechaDer(){
		

		double u1 = 0;
		double u2 = y-3;
		double v1 = clickDerechoX - x;
		double v2 = clickDerechoY - y;
		double numerador = (u1 * v1) + (u2 * v2);
		double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
				* Math.sqrt((v1 * v1) + (v2 * v2));

		double coseno = numerador / denominador;
		//double angulo = Math.acos(coseno);
		
	
		double angulo = Math.acos(coseno);
		angulo = (Math.PI)-angulo;
		 angulo = (angulo * 180 /Math.PI)-90;
		//System.out.println("angulo real "+angulo);
		return angulo;
	}
	public double getAnguloFlechaIzq(){
		double u1 = 0;
		double u2 = y+3;
		double v1 = clickDerechoX - x;
		double v2 = clickDerechoY - y;
		double numerador = (u1 * v1) + (u2 * v2);
		double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
				* Math.sqrt((v1 * v1) + (v2 * v2));

		double coseno = numerador / denominador;
		//double angulo = Math.acos(coseno);
		
	
		double anguloRadianes = Math.acos(coseno);
		
		double angulo =90 + (anguloRadianes*180/Math.PI);
		//System.out.println("angulo real "+angulo);
		return angulo;
	}
	public double getAnguloFlechaArr(){
		double u1 = x+3;
		double u2 = 0;
		double v1 = clickDerechoX - x;
		double v2 = clickDerechoY - y;
		double numerador = (u1 * v1) + (u2 * v2);
		double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
				* Math.sqrt((v1 * v1) + (v2 * v2));

		double coseno = numerador / denominador;
		//double angulo = Math.acos(coseno);
		
	
		double anguloRadianes = Math.acos(coseno);
		
		double angulo = (anguloRadianes*180/Math.PI);
		///System.out.println("angulo real "+angulo);
		return angulo;
	}

	@Override
	public void update(PantallaJuego pantallaJuego){
		//AnimacionArquero ani= (AnimacionArquero) animacion;
		
		boolean dispara = isDisparaFlecha();
		if(dispara){
			disparar(pantallaJuego);
		}
	}
	


}