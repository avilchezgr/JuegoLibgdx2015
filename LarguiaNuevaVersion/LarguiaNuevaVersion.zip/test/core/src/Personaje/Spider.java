package Personaje;

import Auxiliar.Punto;

import com.badlogic.gdx.graphics.Texture;

public class Spider extends Enemigo {
	
	public final static String nombre = "Spider";
	protected int altoFrame = 64;
	protected int anchoFrame = 64;
	protected AnimacionSpider animacion;
	protected Punto pInicial;
	public Spider(float x, float y,int vida) {
		super(x, y,nombre,vida);
		textura = new Texture("images/spider01.png");
		animacion = new AnimacionSpider(this,altoFrame,anchoFrame);
		pInicial = new Punto(x,y);
	}
	
}