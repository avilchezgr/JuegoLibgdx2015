package Personaje;

import com.badlogic.gdx.graphics.g2d.BitmapFont;

public abstract class Enemigo extends Creature{
	protected String nombre;
	protected BitmapFont graphicsNombre;
	protected int vida;
	public Enemigo(float x,float y,String nombre, int vida){
		this.x = x;
		this.y = y;
		this.vida = vida;
		this.nombre = nombre;
		graphicsNombre = new BitmapFont();
		
	}
}