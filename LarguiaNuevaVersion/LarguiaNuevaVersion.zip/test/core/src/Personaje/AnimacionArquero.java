package Personaje;

import Auxiliar.Auxiliar;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class AnimacionArquero extends AnimacionHeroe{
	
	//protected AnimacionFlecha animacionFlecha;
	//protected Flecha flecha;
	
	public AnimacionArquero(Arquero heroe){
	
		super(heroe,64,64); //le estamos pasando el tamaño del ancho y el alto de cada frame
		
		//tiempos que se muestran los distintos frames
		
		tiempoFrameMovimiento = 0.08f;
		tiempoFrameAccion1 = 0.05f;
		tiempoFrameAccion2 = 0.08f;
		
		//CREACION DE LAS FILAS CON LOS FRAMES
		
		//andar
		TextureRegion[] animacionAndarArriba = Auxiliar.getFilaArrayTextRegion(8,9,arrayTextures);
		TextureRegion[] animacionAndarAbajo = Auxiliar.getFilaArrayTextRegion(10,9,arrayTextures);
		TextureRegion[] animacionAndarDerecha = Auxiliar.getFilaArrayTextRegion(11,9,arrayTextures);
		TextureRegion[] animacionAndarIzquierda = Auxiliar.getFilaArrayTextRegion(9,9,arrayTextures);
		
		//disparar
		
		TextureRegion[] animacionDispararArriba = Auxiliar.getFilaArrayTextRegion(16,12,arrayTextures);
		TextureRegion[] animacionDispararAbajo = Auxiliar.getFilaArrayTextRegion(18,12,arrayTextures);
		TextureRegion[] animacionDispararDerecha = Auxiliar.getFilaArrayTextRegion(19,12,arrayTextures);
		TextureRegion[] animacionDispararIzquierda = Auxiliar.getFilaArrayTextRegion(17,12,arrayTextures);
		
		//CREACION DE LAS ANIMACIONES
		
		//animaciones de andar
		
		andaArriba=new Animation(tiempoFrameMovimiento,animacionAndarArriba);
		andaAbajo=new Animation(tiempoFrameMovimiento,animacionAndarAbajo);
		andaDerecha=new Animation(tiempoFrameMovimiento,animacionAndarDerecha);
		andaIzquierda=new Animation(tiempoFrameMovimiento,animacionAndarIzquierda);
		
		//animaciones de disparar
		accion1Arriba = new Animation(tiempoFrameAccion1,animacionDispararArriba);
		accion1Abajo = new Animation(tiempoFrameAccion1,animacionDispararAbajo);
		accion1Derecha = new Animation(tiempoFrameAccion1,animacionDispararDerecha);
		accion1Izquierda = new Animation(tiempoFrameAccion1,animacionDispararIzquierda);
		
		duracionAccion1 = accion1Arriba.getAnimationDuration();
		//duracionAccion2 = accion2Arriba.getAnimationDuration();
		animacionActual = getAnimacionPorDefecto();
		animacionAnterior = getAnimacionPorDefecto();
		
	}
	
	
	
}