package Personaje;

public class AnimacionFlecha  {
	
	//estados posibles de la flecha
	
	
	
	private float duracion;
	
	
	
}