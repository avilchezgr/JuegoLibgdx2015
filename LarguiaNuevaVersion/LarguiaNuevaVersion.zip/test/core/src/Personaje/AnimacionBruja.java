package Personaje;

import Auxiliar.Auxiliar;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class AnimacionBruja extends AnimacionHeroe {

	public AnimacionBruja(Heroe heroe) {
		super(heroe, Heroe.anchoFrame, Heroe.altoFrame);
		tiempoFrameMovimiento = 0.08f;
		tiempoFrameAccion1 = 0.1f;
		tiempoFrameAccion2 = 0.08f;
		
		// TEXTURE REGIONS DE ANDAR
		
		TextureRegion[] animacionAndarArriba = Auxiliar.getFilaArrayTextRegion(8,9,arrayTextures);
		TextureRegion[] animacionAndarAbajo = Auxiliar.getFilaArrayTextRegion(10,9,arrayTextures);
		TextureRegion[] animacionAndarDerecha = Auxiliar.getFilaArrayTextRegion(11,9,arrayTextures);
		TextureRegion[] animacionAndarIzquierda = Auxiliar.getFilaArrayTextRegion(9,9,arrayTextures);
		
		//TEXTURE REGIONS DE ACCION1 opcion varita
		/**
		 *
		TextureRegion[] animacionHechizo1Arriba = Auxiliar.getFilaArrayTextRegion(12,6,arrayTextures);
		TextureRegion[] animacionHechizo1Abajo = Auxiliar.getFilaArrayTextRegion(14,6,arrayTextures);
		TextureRegion[] animacionHechizo1Derecha = Auxiliar.getFilaArrayTextRegion(15,6,arrayTextures);
		TextureRegion[] animacionHechizo1Izquierda = Auxiliar.getFilaArrayTextRegion(13,6,arrayTextures);
		* 
		 * */
		//TEXTURE REGIONS DE ACCION 1 opcion levantar manos
		
		 TextureRegion[] animacionHechizo1Arriba = Auxiliar.getFilaArrayTextRegion(0,7,arrayTextures);
		TextureRegion[] animacionHechizo1Abajo = Auxiliar.getFilaArrayTextRegion(2,7,arrayTextures);
		TextureRegion[] animacionHechizo1Derecha = Auxiliar.getFilaArrayTextRegion(3,7,arrayTextures);
		TextureRegion[] animacionHechizo1Izquierda = Auxiliar.getFilaArrayTextRegion(1,7,arrayTextures);
		
		 
		
		
		// ANIMACIONES ANDAR
		
		andaArriba = new Animation(tiempoFrameMovimiento,animacionAndarArriba);
		andaAbajo = new Animation(tiempoFrameMovimiento,animacionAndarAbajo);
		andaDerecha = new Animation(tiempoFrameMovimiento,animacionAndarDerecha);
		andaIzquierda = new Animation(tiempoFrameMovimiento,animacionAndarIzquierda);
		
		// ANIMACIONES ACCION1
		
		accion1Arriba = new Animation(tiempoFrameAccion1,animacionHechizo1Arriba);
		accion1Abajo = new Animation(tiempoFrameAccion1,animacionHechizo1Abajo);
		accion1Derecha = new Animation(tiempoFrameAccion1,animacionHechizo1Derecha);
		accion1Izquierda = new Animation(tiempoFrameAccion1,animacionHechizo1Izquierda);
		
		animacionActual = getAnimacionPorDefecto();
		animacionAnterior = getAnimacionPorDefecto();
	}
	
}