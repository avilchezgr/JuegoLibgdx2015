package Personaje;

import Auxiliar.Auxiliar;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

public abstract class Magia {
	protected Texture textura;
	protected Animation animacion;
	protected float duracionAnimacionActual = 0;
	protected Rectangle rectangle;
	protected int realAlto = 64;
	protected int realAncho = 64;
	protected int x,y;
	protected String nombreHeroe;
	protected int altoFrame = 128;
	protected int anchoFrame = 128;
	protected boolean estado = true;
	protected float contador = 0;
	protected int damage; //= 200;
	public final static boolean estadoProceso = true;
	public final static boolean estadoFinished = false;
	protected float tFrameAnimacion = 0.10f;
	protected String rutaTextura = "torrentacle";
	
	public Magia(String nombreHeroe,int x, int y, int damage){
		this.x = x;
		this.y = y;
		rectangle = new Rectangle(x-(this.realAncho/3),y-this.realAlto/2,realAncho,realAlto);
		textura = new Texture("images/"+rutaTextura+".png");	
		TextureRegion tRegionAnimacion = new TextureRegion(textura);
		TextureRegion[][] arrayTextures = tRegionAnimacion.split(textura, anchoFrame, altoFrame);
		TextureRegion[] textReg = Auxiliar.fromArrayToRowTextRegion(arrayTextures);
		animacion = new Animation(tFrameAnimacion,textReg);
		this.nombreHeroe = nombreHeroe;
		this.damage = damage;
	}
	
	
	public Animation getAnimacion() {
		return animacion;
	}
	public float getDuracionAnimacionActual() {
		return duracionAnimacionActual;
	}
	public String getNombreHeroe() {
		return nombreHeroe;
	}
	public int getAltoFrame() {
		return altoFrame;
	}
	public int getAnchoFrame() {
		return anchoFrame;
	}
	public Texture getTextura(){
		return textura;
	}
	public void incrementarDuracion(){
		duracionAnimacionActual += Gdx.graphics.getDeltaTime();
	}
	public TextureRegion getFrameActual(){
		
		if(duracionAnimacionActual > animacion.getAnimationDuration()){
			estado = Magia.estadoFinished;
		}
		TextureRegion reg = animacion.getKeyFrame(duracionAnimacionActual,false);
		incrementarDuracion();
		
		return reg;	
		
	}
	public Rectangle getRectangle(){
		return rectangle;
	}
	public int getRealAncho(){
		return realAncho;
	}
	public int getRealAlto(){
		return realAlto;
	}
	public int getY() {
		// TODO Auto-generated method stub
		return y;
	}
	public int getX() {
		// TODO Auto-generated method stub
		return x;
	}
	public boolean getEstado() {
		// TODO Auto-generated method stub
		return estado;
	}
	public void actualizarContador(float delta){
		contador  += delta;
		
	}
	public abstract boolean isFrameDamage();
	public float getContador() {
		// TODO Auto-generated method stub
		return contador;
	}
	public void setEstado(boolean est) {
		// TODO Auto-generated method stub
		estado = est;
	} 
}
