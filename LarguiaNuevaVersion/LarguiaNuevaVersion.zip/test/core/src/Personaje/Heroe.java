package Personaje;

import Input.ControladorEntrada;
import Larguia.PantallaJuego;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;


public abstract class Heroe extends Creature {

	//protected Texture textura;
	
	protected BitmapFont graphicsNombre;
	
	protected AnimacionHeroe animacion;
	public final static int tipoArquero = 0;
	public final static int tipoBruja = 1;
	public final static int anchoFrame=64;
	public final static int altoFrame=64;
	public final static int realAlto = 50;
	public final static int realAncho = 30;
	private boolean morir = false;
	//Datos del personaje
	protected int velocidadMovimiento;
	protected String nombre;
	//protected float x,y;
	protected float clickDerechoX,clickDerechoY;
	private boolean accionExterna = false;
	protected int anchoReal;
	protected int altoReal;
	protected Rectangle rectangle;
	protected int vida = 1000;
	protected boolean primeraVez = true;
	AnimacionSerializada serializada;

	
	
	public Heroe(float x,float y,String nombre,int nFoto){
		this.x=x;
		this.y=y;
		this.nombre=nombre;
		graphicsNombre=new BitmapFont();
		
		serializada = new AnimacionSerializada();
		serializada.setFoto(nFoto);
		serializada.setPosX(x);
		serializada.setPosY(y);
		serializada.setNombre(nombre);
		serializada.setVida(vida);
		this.rectangle = new Rectangle (x-(realAncho/2),y-(realAlto/2),realAncho,realAlto);
	}
	
public BitmapFont getGraphicsNombre(){
		
		return graphicsNombre;
	}
	public float getX(){
		
		return x;
	}
	
	
	public float getY(){
		
		return y;
	}
	
	/**
	 * Actualiza animacion del personaje
	 * Si entra en el if de accionExterna() es que hay una acccion externa actuando sobre el personaje, como que un enemigo lo mate o interrumpa su accion
	 * El primer else decide si puede realizar una nueva accion que haya disponible, si puede la hace
	 * El segundo else es si no puede realizar una accion nueva o esta realizando una accion anterior, aumenta el tiempo de duracion y saca esta animacion.
	 * La forma de cambiar las animaciones es con el metodo de AnimacionHeroe setAnimacionActual(Animation)
	 * */
	public TextureRegion actualizarAnimacion(ControladorEntrada controlador){
		
		//hacer que en controlador solo pueda haber una accion activada a la vez.
		
		boolean seRepite = false;
		//System.out.println(animacion.getEstado());
		if(animacion.isAccionTerminada() && animacion.isAnimacionAccion()){
			//System.out.println("Entramos en el lado oscuro");
			animacion.setAnimacionUltimaDireccion();
			
		}
		Animation nuevaAnimacion = animacion.getAccionPulsada(controlador.getAccionPulsada(x,y));
		
		if(accionExterna){
			
			if(morir){
				if(animacion.isAnimacionMorir() && !animacion.isAccionTerminada()){
					animacion.incrementarDuracion();
					
				}else if(!animacion.isAnimacionMorir()){
					System.out.println("ORDEN CORRECTO");
					animacion.setAnimacionActual(animacion.animacionMorir);
					animacion.setDuracion(0);
				}else{//animacionTerminada
					
				}
			}
		} 
			
	
		else if(controlador.hayTeclaActivada() && sePuedeHacerNuevaAccion() && nuevaAnimacion != null && nuevaAnimacion!=animacion.getAnimacionActual()){	
			//para cambios como que al morir no pueda hacer acciones habria que cambiar algo dentro de este if
			
			//System.out.println("Entra en el if de nueva accion");
			if(animacion.isAnimacionAccion1(nuevaAnimacion)){
				//aqui puede haber fallo
				setClickDerecho(controlador.getClickDerechoX(),controlador.getClickDerechoY());
				if(this instanceof Arquero){
					((Arquero)this).primeraVez = true;
				}else if(this instanceof Bruja){
					((Bruja)this).primeraVez = true;
				}
			}
			
			animacion.setDuracion(0);
			
			
			animacion.setAnimacionActual(nuevaAnimacion);
			//cambiar metodo para que funcione
			
		}else{//no hay nueva accion
			
			//if(animacion.isAnimacionMovimientoOCasteo() && controlador.hayDireccionActivada()){
				//si es animacion que requiere tener pulsada la tecla para que cambie
			//System.out.println(controlador.hayDireccionActivada()+" "+animacion.isAnimacionMovimientoOCasteo());
			if(animacion.isAnimacionMovimientoOCasteo() && controlador.hayDireccionActivada()){ //si es animacion de movimiento
				//System.out.println("he encontrado el problema");
				animacion.incrementarDuracion();
				seRepite = animacion.getSeRepite(animacion.getAnimacionActual()); 
				
			}
			else if(animacion.isAnimacionAccion() && !animacion.isAccionTerminada()){
				animacion.incrementarDuracion();
				
				seRepite = animacion.getSeRepite(animacion.getAnimacionActual()); 
			//	System.out.println("sospechoso"+animacion.getEstado());
			}
			float duracion = animacion.getDuracion();
			
		//	System.out.println(" "+duracion);
			animacion.setDuracion(duracion);
			
			//if(AnimacionHeroe.getSeRepite(animacion.getAnimacionActual())){//cambiar metodo para que esto no sea siempre false
			
			//}
		}
		// se Repite se cambia aqui al final
		//System.out.println(seRepite);
		TextureRegion frame = animacion.getAnimacionActual().getKeyFrame(animacion.getDuracion(),seRepite);
		actualizarAnimacionSerializada();
		
		return frame;
	}
	
	
	public boolean accionExterna(){
		//animacion.is
		return false;
	}
	
	public abstract void actualizarAnimacionSerializada();
	
	/**
	 * Las condiciones para hacer una nueva accion actuales (si cambio algo habria que cambiarlas)
	 * Si el personaje esta andando, si el personaje ha terminado la accion que estaba haciendo
	 * */
	public boolean sePuedeHacerNuevaAccion(){
		boolean permiso = true;
		
		boolean accionEnProceso = animacion.isAnimacionAccion()
				&& !animacion.isAccionTerminada();
		boolean ignoramosAccionEnProceso = true;
		if (!ignoramosAccionEnProceso) {
			if (accionEnProceso) {
				permiso = false;
			}
		}
		return permiso;
	}
	
	public void setPos(float x,float y){
		this.x=x;
		this.y=y;
		serializada.setPosX(x);
		serializada.setPosY(y);
		rectangle.set(x-(realAncho/2),y-(realAlto/2),realAncho,realAlto);
		
	}
	public Texture getTextura(){
		
		return textura;
	}
	public Rectangle getRectangle(){
		return rectangle;
	}
	public String getNombre(){
		
		return nombre;
	}
	public AnimacionHeroe getAnimacion(){
				
		return animacion;
	}
	public int getVelocidadMovimiento(){
		
		return velocidadMovimiento;
	}
	public void setClickDerecho(float cX,float cY){
		this.clickDerechoX=cX;
		this.clickDerechoY=cY;
		
	}
	public abstract void update(PantallaJuego pantallaJuego);
	
	/**
	 * Devuelve el ancho real que hemos medido en photoshop del muñeco
	 * */
	public int getAnchoReal(){
		return anchoReal;
	}
	/**
	 * Devuelve el alto real que hemos medido en photoshop del muñeco
	 * */
	public int getAltoReal(){
		return altoReal;
	}
//	public int getFrameActual(){
		
	//	return frameActual;
//	}
	public AnimacionSerializada getSerializada(){
		return serializada;
	}
	public void setAccionExterna(boolean accion){
		this.accionExterna = accion;
	}

	public void recibirFlechazo() {
		vida = vida - 100;
		
		// TODO Auto-generated method stub
		checkVidaMenorCero();
	}
	public void morir(){
		this.accionExterna = true;
		this.morir = true;
		System.out.println("MUERTE");
	}

	public boolean isDead() {
		// TODO Auto-generated method stub
		return morir;
	}
	public int getVida(){
		return vida;
	}
	public void checkVidaMenorCero(){
		if(vida <= 0){
			vida = 0;
			morir();
		}
	}
	public void recibirMagia(Magia magia) {
		// TODO Auto-generated method stub
		if(magia instanceof Torrentacle){
			vida = vida - 200;
			checkVidaMenorCero();
		}
	}
}