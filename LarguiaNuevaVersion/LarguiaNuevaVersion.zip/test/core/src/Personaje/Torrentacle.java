package Personaje;

import Auxiliar.Auxiliar;
import Larguia.PantallaJuego;
import Red.FlechaVirtual;
import Red.TorrentacleVirtual;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

public class Torrentacle extends Magia{

	
	
	
	

	
	
	public Torrentacle( String nombreHeroe,int x, int y, int damage){
		super(nombreHeroe,x,y,damage);
		
	}
	public Torrentacle(TorrentacleVirtual tVirtual, PantallaJuego pantalla){
		super(tVirtual.getNombre(),(int) tVirtual.getX(),(int) tVirtual.getY(),tVirtual.getDamage());
		//this.pantalla = pantalla;
		
	}
	public boolean isFrameDamage(){
		return animacion.getKeyFrame(duracionAnimacionActual) == animacion.getKeyFrame(9*tFrameAnimacion, false);
		// TODO Auto-generated method stub
		
	}
	public int getDamage() {
		// TODO Auto-generated method stub
		return damage;
	}
}