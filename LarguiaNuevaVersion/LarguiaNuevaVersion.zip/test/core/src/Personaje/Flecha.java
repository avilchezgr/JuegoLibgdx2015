package Personaje;

import java.util.ArrayList;

import Larguia.PantallaJuego;
import Personaje.red.GestorJugadoresVirtuales;
import Personaje.red.JugadorSerializadoVirtual;
import Red.FlechaVirtual;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

public class Flecha {
	
	
	//private TextureRegion arrayTextures[][];
	//private AnimacionFlecha animacion;
	
	public final static int altoFotograma = 8;
	public final static int anchoFotograma = 32;
	public final static int direccionArriba = 0;
	public final static int direccionAbajo = 1;
	public final static int direccionIzquierda = 2;
	public final static int direccionDerecha = 3;
	
	public static int velocidadMovimiento=1000;
	//public static int velocidadMovimiento = 100;
	
	
	private Arquero heroe;
	private double x,y;
	private double angulo;
	private float objetivoX,objetivoY;
	private int damage;
	
	private Texture texturaFlecha;
	
	private TextureRegion textRegionFlecha;
	private Sprite spriteFlecha;
	
	public final static int estadoVolando = 0;
	public final static int estadoChoca = 1;
	public final static int estadoChocaHeroe = 2;
	private float contador;
	
	private int estado;
	private int tipo;
	private PantallaJuego pantalla;
	private String nombre;
	/**
	 * tipo lo dejamos abierto a que en el futuro alla varias flechas, como flechas de fuego normales envenadadas.
	 * angulo quiere decir angulo con el semieje x positivo
	 * */
	public Flecha(FlechaVirtual fVirtual, PantallaJuego pantalla){
		this.estado = estadoVolando;
		this.pantalla = pantalla;
		this.x = fVirtual.getX();
		this.y = fVirtual.getY();
		this.objetivoX = fVirtual.getObjX();
		this.objetivoY = fVirtual.getObjY();
		this.damage = fVirtual.getDamage();
		this.texturaFlecha = new Texture("images/arrow1.png");
		spriteFlecha = new Sprite(texturaFlecha,0,0,anchoFotograma,altoFotograma);
		spriteFlecha.setPosition((float) x,(float) y);
		spriteFlecha.setOrigin(0,4);
		this.angulo = fVirtual.getAngulo();
		this.tipo = fVirtual.getTipo();
		this.nombre = fVirtual.getNombre();
		spriteFlecha.rotate((float) angulo);
		
	}
	public Flecha(String nombre,float x,float y,float objX,float objY, int tipo, int damage,float angulo,PantallaJuego pantalla){
		this.estado = estadoVolando;
		this.nombre = nombre;
		this.pantalla = pantalla;
		this.x = x;
		this.y = y;// - altoFotograma/2;
		objetivoX = objX;
		objetivoY = objY;
		this.damage = damage;
		texturaFlecha = new Texture("images/arrow1.png");
		//System.out.println("flecha "+(int)x+","+(int)y);
		//(Texture texture, int srcX, int srcY, int srcWidth, int srcHeight) {
		spriteFlecha = new Sprite(texturaFlecha,0,0,anchoFotograma,altoFotograma);
		spriteFlecha.setPosition((float) x,(float) y);
		spriteFlecha.setOrigin(0,4);
		this.angulo = angulo;
		spriteFlecha.rotate((float) angulo);
		this.tipo = tipo;
		this.nombre = nombre;
	}
	
	public Texture getTextura(){
		return texturaFlecha;
	}
	public Sprite getSprite(){
		return spriteFlecha;
	}
	public double getX(){
		return x;
	}
	public double getY(){
		return y;
	}
	public void setPosicion(double x, double y){
		this.x = x;
		this.y = y;
	}
	public int getTipo(){
		return tipo;
	}
	public double getAngulo(){
		
		return angulo;
	}
	
	public void calcularNuevaPosicion(GestorJugadoresVirtuales gestorJugadores) {
		Rectangle rect = new Rectangle(((float)x-1),((float)y-1),2,2);
		if(rect.overlaps(pantalla.getHeroe().getRectangle()) && 
				!pantalla.getHeroe().getNombre().equals(nombre)){
			pantalla.getHeroe().recibirFlechazo();
			estado = estadoChocaHeroe;
			
		}else if(gestorJugadores.getColisionaFlecha((float) x,(float) y)){
			estado = estadoChocaHeroe;
		}else{
		float delta = Gdx.graphics.getDeltaTime();

		double u1;
		double u2;
		double v1;
		double v2;
		double numerador;
		double denominador;
		double seno;
		double nuevaX;
		double nuevaY;
		double coseno;
		double angle;
		switch (tipo) {
		case direccionIzquierda:
			angle =Arquero.anguloVectores(x+3, 0, objetivoX-x, objetivoY-y);
			
			coseno = Math.cos(angle);	
			seno = Math.sin(Math.acos(coseno));
			if (x < objetivoX) {
				estado = estadoChoca;	
			} else if(objetivoY - y >= 0 && colisiona(x + coseno * velocidadMovimiento * delta,y + seno * velocidadMovimiento * delta)){
				estado = estadoChoca;
			}else if(objetivoY - y < 0  && colisiona(x + coseno * velocidadMovimiento * delta,y - seno * velocidadMovimiento * delta)){
				estado = estadoChoca;
			}else {
				
				nuevaX = x + coseno * velocidadMovimiento * delta;
				if (objetivoY - y >= 0) {
					nuevaY = y + seno * velocidadMovimiento * delta;
				} else {
					nuevaY = y - seno * velocidadMovimiento * delta;
				}
				this.setPosicion(nuevaX, nuevaY);
				spriteFlecha.setPosition((float) nuevaX, (float) nuevaY);
			}
			break;
		case direccionDerecha:
			angle =Arquero.anguloVectores(x+3, 0, objetivoX-x, objetivoY-y);
			
			coseno = Math.cos(angle);
			seno = Math.sin(Math.acos(coseno));
			if (x > objetivoX ) {
				estado = estadoChoca;
			} else if(objetivoY - y >= 0 && colisiona( x + coseno * velocidadMovimiento * delta,nuevaY = y + seno * velocidadMovimiento * delta)){
				estado = estadoChoca;
			}else if(objetivoY - y < 0 && colisiona(x + coseno * velocidadMovimiento * delta,y - seno * velocidadMovimiento * delta)){
				estado = estadoChoca;
			}else {
				
				nuevaX = x + coseno * velocidadMovimiento * delta;
				if (objetivoY - y >= 0) {
					nuevaY = y + seno * velocidadMovimiento * delta;
				} else {
					nuevaY = y - seno * velocidadMovimiento * delta;
				}
				this.setPosicion((float) nuevaX, (float) nuevaY);
				spriteFlecha.setPosition((float) nuevaX, (float) nuevaY);
			}
			break;
		case direccionArriba:
			angle = Arquero.anguloVectores(x+3, 0, objetivoX - x, objetivoY - y);
			
			coseno = Math.cos(angle);
			seno = Math.sin(angle);
			if(y>objetivoY || colisiona( x + coseno * velocidadMovimiento * delta, y + seno * velocidadMovimiento * delta)){
				System.out.println("arriba");
				estado = estadoChoca;
			}else{
				//System.out.println("arriba");
				//double angulo = Arquero.anguloVectores(x+3, 0, objetivoX - x, objetivoY - y);
			
				//nuevaX = x + coseno * velocidadMovimiento * delta;
				nuevaY = y + seno * velocidadMovimiento * delta;
				//nuevaY = y - seno * velocidadMovimiento * delta;
				nuevaX = x + coseno * velocidadMovimiento * delta;
				
				this.setPosicion((float) nuevaX, (float) nuevaY);
				spriteFlecha.setPosition((float) nuevaX, (float) nuevaY);
			}

			break;
		case direccionAbajo:
			
			angle = Arquero.anguloVectores(x - 3, 0, objetivoX - x,
					objetivoY - y);
			
			coseno = Math.cos(angle);
			seno = Math.sin(angle);
			
			if (y < objetivoY || colisiona( x + coseno * velocidadMovimiento * delta, y - seno * velocidadMovimiento * delta)) {
				estado = estadoChoca;
			} else {
				 
				
				nuevaY = y - seno * velocidadMovimiento * delta;
				//nuevaY = y - seno * velocidadMovimiento * delta;
				
				nuevaX = x + coseno * velocidadMovimiento * delta;
				
				this.setPosicion((float) nuevaX, (float) nuevaY);
				spriteFlecha.setPosition((float) nuevaX, (float) nuevaY);
			}
			break;
		}

	}
	}
	public int getEstado(){
		
		return estado;
	}
	
	
	
	//COLISIONES
	
	public boolean colisiona(double x,double y){
		float tileWidth = pantalla.getCollisionLayer().getTileWidth(), tileHeight = pantalla.getCollisionLayer().getTileHeight();
		boolean colisiona = false;
		
		
		try{
        	if(pantalla.getCollisionLayer().getCell((int)((x) / tileWidth) , 
        			(int) (y /tileHeight)).getTile().getProperties().containsKey("blocked")){
			//	System.out.println("blocked");
        		colisiona = true;
        	}
				
        	}catch(Exception ex){
        	//	System.err.println("null cell");
        	}
		
		
		return colisiona;
		
	}
	
	//COLISIONES
	
	
	public void actualizarContador(float delta){
		contador += delta;
		
	}
	public float getContador(){
		return contador;
	}
	
	
	
	
}