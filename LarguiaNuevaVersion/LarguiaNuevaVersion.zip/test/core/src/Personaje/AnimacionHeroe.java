package Personaje;

import Auxiliar.Auxiliar;
import Input.ControladorEntrada;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public abstract class AnimacionHeroe {

	protected int estado;
	protected float duracionAnimacionActual;
	protected Animation animacionActual; 
	
	protected int estadoAnterior;
	protected Animation animacionAnterior;
	//cosas relacionadas con las texturas
	
	protected TextureRegion arrayTextures[][];
	protected Texture textura;
	protected int altoFrame;
	protected int anchoFrame;
	
	/**
	 * ESTADOS
	 * */
	//Estados movimiento
	public final static int estadoAnimacionIzquierda=0;
	public final static int estadoAnimacionDerecha=1;
	public final static int estadoAnimacionArriba=2;
	public final static int estadoAnimacionAbajo=3;
	
	
	//Estados accion1
	
	public final static int estadoAnimacionAccion1Izq=4;
	public final static int	estadoAnimacionAccion1Der=5;
	public final static int	estadoAnimacionAccion1Arr=6;
	public final static int	estadoAnimacionAccion1Abaj=7;
	protected float duracionAccion1;// = getAnimationDuration();
	
	//Estados accion2
	
	public final static int estadoAnimacionAccion2Izq=8;
	public final static int	estadoAnimacionAccion2Der=9;
	public final static int	estadoAnimacionAccion2Arr=10;
	public final static int	estadoAnimacionAccion2Abaj=11;
	protected float duracionAccion2;// = getAnimationDuration();
	
	//Estados morir
	
	public final static int estadoAnimacionMorir = 12;
	//protected boolean accionEnProceso;
	
	//animaciones de andar
	
	protected Animation andaDerecha;
	protected Animation andaIzquierda;
	protected Animation andaArriba;
	protected Animation andaAbajo;
	
	//animacion accion1 
	
	protected Animation accion1Derecha;
	protected Animation accion1Izquierda;
	protected Animation accion1Arriba;
	protected Animation accion1Abajo;
	
	//animacion accion2
	
	protected Animation accion2Derecha;
	protected Animation accion2Izquierda;
	protected Animation accion2Arriba;
	protected Animation accion2Abajo;
	
	//animacion morir
	
	protected Animation animacionMorir;
	
	public static float tiempoFrameMovimiento = 0.08f;
	public static float tiempoFrameAnimacionMorir = 0.1f;
	public static float tiempoFrameAccion1;
	public static float tiempoFrameAccion2;
	
	public AnimacionHeroe(Heroe heroe,int anFrame,int alFrame){
		
		duracionAnimacionActual=0;
		altoFrame=alFrame;
		anchoFrame=anFrame;
		//ladoFrame=lFrame;
		estado=estadoAnimacionAbajo;
		textura=heroe.getTextura();
		
		TextureRegion tRegionAnimacion = new TextureRegion(heroe.getTextura());
		arrayTextures = tRegionAnimacion.split(textura, anchoFrame, altoFrame);
		TextureRegion[] regionAnimacionMorir = Auxiliar.getFilaArrayTextRegion(20,6,arrayTextures);
		animacionMorir = new Animation(tiempoFrameAnimacionMorir,regionAnimacionMorir);
		
	}
	
	public Animation getAnimacionActual(){
		
		Animation animacion;
		
		switch(estado){
		
		case estadoAnimacionAbajo:
			animacion = andaAbajo;
			break;
		case estadoAnimacionArriba:
			animacion = andaArriba;
			break;
		case estadoAnimacionDerecha:
			animacion = andaDerecha;
			break;
		case estadoAnimacionIzquierda:
			animacion = andaIzquierda;
			break;
		case estadoAnimacionAccion1Abaj:
			animacion = accion1Abajo;
		break;
		case estadoAnimacionAccion1Arr:
			animacion = accion1Arriba;
			break;
		case estadoAnimacionAccion1Der:
			animacion = accion1Derecha;
			break;
		case estadoAnimacionAccion1Izq:
			animacion = accion1Izquierda;
			break;
		case estadoAnimacionMorir:
			animacion = animacionMorir;
			break;
		default:
			animacion = null;
			break;

		}

		return animacion;

	}

	public int getEstado() {
		
		return estado;
	}
	
	public void incrementarDuracion(){
		duracionAnimacionActual += Gdx.graphics.getDeltaTime();
		
	}
	public Animation getAnimacionPorDefecto(){
		
		return andaAbajo;
	}
	public Animation getAccionPulsada(int n){
		//metodo que devuelve la animacion actual del controlador
		Animation animation = null;
		switch(n){
		case ControladorEntrada.direccionAbajo:
			animation = andaAbajo;
			break;
		case ControladorEntrada.direccionArriba:
			animation = andaArriba;
			break;
		case ControladorEntrada.direccionIzquierda:
			animation = andaIzquierda;
			break;
		case ControladorEntrada.direccionDerecha:
			animation = andaDerecha;
			break;
		case ControladorEntrada.iAccion1Abajo:
			animation = accion1Abajo;
			break;
		case ControladorEntrada.iAccion1Arriba:
			animation = accion1Arriba;
			break;

		case ControladorEntrada.iAccion1Izquierda:
			animation = accion1Izquierda;
			break;
		case ControladorEntrada.iAccion1Derecha:
			animation = accion1Derecha;
			break;
			
		case ControladorEntrada.iAccion2Abajo:
			animation = accion2Abajo;
			break;
		case ControladorEntrada.iAccion2Arriba:
			animation = accion2Arriba;
			break;

		case ControladorEntrada.iAccion2Izquierda:
			animation = accion2Derecha;
			break;
		case ControladorEntrada.iAccion2Derecha:
			animation = accion2Derecha;
			break;
		}
		
		return animation;
	}
	public boolean isAnimacionAccion(){
		
		boolean isAnimacionAccion = estado == AnimacionHeroe.estadoAnimacionAccion1Abaj 
				||  estado == AnimacionHeroe.estadoAnimacionAccion1Arr 
				|| estado == AnimacionHeroe.estadoAnimacionAccion1Der
				|| estado ==  AnimacionHeroe.estadoAnimacionAccion1Izq;
		return isAnimacionAccion;
	}
	public boolean isAnimacionMorir(){
		return estado == AnimacionHeroe.estadoAnimacionMorir;
	}
	public boolean isAnimacionAccion1(){
		
		boolean isAnimacionAccion = estado == AnimacionHeroe.estadoAnimacionAccion1Abaj 
				||  estado == AnimacionHeroe.estadoAnimacionAccion1Arr 
				|| estado == AnimacionHeroe.estadoAnimacionAccion1Der
				|| estado ==  AnimacionHeroe.estadoAnimacionAccion1Izq;
		return isAnimacionAccion;
	}
	
	
	public Animation getAndaDerecha() {
		return andaDerecha;
	}

	public void setAndaDer(Animation andaDer) {
		this.andaDerecha = andaDer;
	}

	public Animation getAndaIzquierda() {
		return andaIzquierda;
	}

	public void setAndaIzquierda(Animation andaIzq) {
		this.andaIzquierda = andaIzq;
	}

	public Animation getAndaArriba() {
		return andaArriba;
	}

	public void setAndaArriba(Animation andaArriba) {
		this.andaArriba = andaArriba;
	}

	public Animation getAndaAbajo() {
		return andaAbajo;
	}

	public void setAndaAbajo(Animation andaAbajo) {
		this.andaAbajo = andaAbajo;
	}
	public void resetDuracion(){
		duracionAnimacionActual=0;
	}

	public void modificarDuracion(float delta, int estado) {
		
		if (estado == this.estado) {
			duracionAnimacionActual += delta;
			// System.out.println("if");
		} else {
			
			duracionAnimacionActual = 0;
			this.estado = estado;
			
			
		}

	}

	public float getDuracion() {

		return duracionAnimacionActual;
	}
	
	public void setDuracion(float dura){
		duracionAnimacionActual=dura;
	}
	
	public void setAnimacionActual(Animation animation){
		
		animacionActual = animation;
		estado = actualizarEstado(animation);
		
		
	}
	public boolean isAccionTerminada(){
		//System.out.println("duracionanimacionactual"+animacionActual);
		boolean terminada = duracionAnimacionActual >= animacionActual.getAnimationDuration();
		
		return terminada;
	}
	public int actualizarEstado(Animation animation){
		
		int estado = -1;
		
		//andar
	
		if(animation.equals(andaAbajo)){
			estado = AnimacionHeroe.estadoAnimacionAbajo;
		}
		else if(animation.equals(andaArriba)){
			estado = AnimacionHeroe.estadoAnimacionArriba;
		}
		else if(animation.equals(andaDerecha)){
			estado = AnimacionHeroe.estadoAnimacionDerecha;
		}else if(animation.equals(andaIzquierda)){
			estado = AnimacionHeroe.estadoAnimacionIzquierda;
		}		
		//accion 1
		else if(animation.equals(accion1Abajo)){
			estado = AnimacionHeroe.estadoAnimacionAccion1Abaj;
		}
		else if(animation.equals(accion1Arriba)){
			estado = AnimacionHeroe.estadoAnimacionAccion1Arr;
		}
		else if(animation.equals(accion1Derecha)){
			
			estado = AnimacionHeroe.estadoAnimacionAccion1Der;
		}
		else if(animation.equals(accion1Izquierda)){
			
			estado = AnimacionHeroe.estadoAnimacionAccion1Izq;
		}
		//accion 2
		else if(animation.equals(accion2Abajo)){
			estado = AnimacionHeroe.estadoAnimacionAccion2Abaj;
		}
		else if(animation.equals(accion2Arriba)){
			estado = AnimacionHeroe.estadoAnimacionAccion2Arr;
		}
		else if(animation.equals(accion2Derecha)){
			
			estado = AnimacionHeroe.estadoAnimacionAccion2Der;
		}
		else if(animation.equals(accion2Izquierda)){
			
			estado = AnimacionHeroe.estadoAnimacionAccion2Izq;
		}else if(animation.equals(animacionMorir)){
			
			estado = AnimacionHeroe.estadoAnimacionMorir;
		}
		
		return estado;
		
	}
	public boolean getSeRepite(Animation animacionActual2) {
		// TODO Auto-generated method stub
		boolean variable = false;
		
		if(estado == estadoAnimacionAbajo || estado == estadoAnimacionArriba || estado == estadoAnimacionDerecha || estado == estadoAnimacionIzquierda){
			
			variable = true;
		}
		return variable;
	}
	
	public boolean isAnimacionMovimientoOCasteo() {
		// TODO Auto-generated method stub
		boolean variable = false;
		if(estado == estadoAnimacionAbajo || estado == estadoAnimacionArriba || estado == estadoAnimacionDerecha || estado == estadoAnimacionIzquierda){
			
			variable = true;
		}
		return variable;
	}
	public boolean isAnimacionMovimientoArriba(){
		return estado == estadoAnimacionArriba;
	}
	public boolean isAnimacionMovimientoAbajo(){
		return estado == estadoAnimacionAbajo;
	}
	public boolean isAnimacionMovimientoIzquierda(){
		return estado == estadoAnimacionIzquierda;
	}
	public boolean isAnimacionMovimientoDerecha(){
		return estado == estadoAnimacionDerecha;
	}
	public boolean isAnimacionAccion1Arriba(){
		return estado ==estadoAnimacionAccion1Arr;
	}
	public boolean isAnimacionAccion1Abajo(){
		return estado ==estadoAnimacionAccion1Abaj;
	}
	public boolean isAnimacionAccion1Derecha(){
		return estado ==estadoAnimacionAccion1Der;
	}
	public boolean isAnimacionAccion1Izquierda(){
		return estado ==estadoAnimacionAccion1Izq;
	}
	
	public Animation getAnimacionAnterior(){
		return animacionAnterior;
	}

	public void setAnimacionUltimaDireccion() {
		// TODO Auto-generated method stub
		switch (estado) {
		case estadoAnimacionAccion1Abaj:
			setAnimacionActual(andaAbajo);
			break;
		case estadoAnimacionAccion1Arr:
			setAnimacionActual(andaArriba);
			break;
		case estadoAnimacionAccion1Der:
			setAnimacionActual(andaDerecha);
			break;
		case estadoAnimacionAccion1Izq:
			setAnimacionActual(andaIzquierda);
			break;

		}

	}

	public int getAnchoFrame() {
		// TODO Auto-generated method stub
		return anchoFrame;
	}

	public int getAltoFrame() {
		// TODO Auto-generated method stub
		return altoFrame;
	}

	public boolean isAnimacionAccion1(Animation nuevaAnimacion) {
		// TODO Auto-generated method stub
		boolean isAnimacionAccion=nuevaAnimacion.equals(accion1Arriba) || nuevaAnimacion.equals(accion1Abajo) || nuevaAnimacion.equals(accion1Derecha) || nuevaAnimacion.equals(accion1Izquierda);
	
		return isAnimacionAccion;
	}
	public float getDuracionAnimacionAndar(){
		return tiempoFrameMovimiento*9;
	}
}