package Personaje;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import Larguia.PantallaJuego;
import Personaje.red.GestorJugadoresVirtuales;
import Personaje.red.JugadorSerializadoVirtual;

public class HebraColisionHeroe extends Thread{
	private Heroe heroe;
	
	private boolean collides;

	private GestorJugadoresVirtuales gestorJugadores;
	
	public HebraColisionHeroe(GestorJugadoresVirtuales gestorJugadores,Heroe heroe){
		collides = false;
		this.gestorJugadores = gestorJugadores;
		this.heroe = heroe;
		
	}
	
	public void run(){
		while(true){
			System.out.println("antes de empezar");
			if(gestorJugadores.getMapaUsuariosVirtuales().size()>0){
			ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(gestorJugadores.getMapaUsuariosVirtuales().values());
			boolean auxCollides = false;
			for(int i = 0; i<valueList.size(); i++){
				if(colisionaConHeroe(valueList.get(i))){
					auxCollides = true;
					System.out.println("Collides");
					break;
				}
			}
			collides = auxCollides;
			}
		}
		
	}
	
	public boolean colisionaConHeroe(JugadorSerializadoVirtual jugador){
		System.out.println("adasdfasdf");
		return  heroe.getRectangle().overlaps(jugador.getRectangle());
		
	}
	public boolean getCollides(){
		return collides;
	}
}