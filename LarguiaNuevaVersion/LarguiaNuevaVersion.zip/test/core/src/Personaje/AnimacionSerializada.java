package Personaje;

import Red.Protocolo.Protocolo;

public class AnimacionSerializada {
	
	private int fila;
	private int columna;
	private int foto;
	private float posX;
	private float posY;
	private String nombre;
	private int vida;
	
	public AnimacionSerializada(){
		
	}
	public AnimacionSerializada(int fila, int columna, int foto){
		this.fila = fila;
		this.columna =columna;
		this.foto = foto;
		
	}
	public int getFila() {
		return fila;
	}
	public void setFila(int fila) {
		this.fila = fila;
	}
	public int getColumna() {
		return columna;
	}
	public void setColumna(int columna) {
		this.columna = columna;
	}
	public int getFoto() {
		return foto;
	}
	public void setFoto(int foto) {
		this.foto = foto;
	}
	public float getPosX() {
		return posX;
	}
	public void setPosX(float posX) {
		this.posX = posX;
	}
	public float getPosY() {
		return posY;
	}
	public void setPosY(float posY) {
		this.posY = posY;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public byte[] formarMensajeActualizacion(){
		String mensaje = Protocolo.formarMensajeActualizacion(nombre, (int) posX,(int) posY, foto, fila, columna, vida);
		byte[] bytes = mensaje.getBytes();
		return bytes;
	}
	public void setVida(int vida) {
		// TODO Auto-generated method stub
		this.vida = vida;
		
	}
}