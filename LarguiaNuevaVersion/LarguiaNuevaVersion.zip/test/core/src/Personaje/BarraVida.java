package Personaje;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;

public class BarraVida {
	
	//private ShapeRenderer shaper;
	public final static int anchoBarra = 50;
	public final static int altoBarra = 5;
	public final static int vidaMaxima = 1000;
	/**
	 * Recibe coordenada x e y del heroe
	 * */
	public static void dibujarNuevaBarra(float x, float y,int vida,ShapeRenderer shaper){
		float xMedio = x;
		float yMedio = y + Heroe.altoFrame/2;
		float xInicio = xMedio - BarraVida.anchoBarra/2;
		float yInicio = yMedio - BarraVida.altoBarra/2;
		shaper.begin(ShapeType.Filled);
		//System.out.println(vida);
		double longitudVida = BarraVida.anchoBarra *  ((double) vida/BarraVida.vidaMaxima);
		//System.out.println( "porunaje " +double(vida/BarraVida.vidaMaxima));
		double longitudMuerte = BarraVida.anchoBarra - longitudVida;
		shaper.setColor(Color.GREEN);	
		
		shaper.rect(xInicio, yInicio, (float) longitudVida, BarraVida.altoBarra);
		shaper.setColor(Color.RED);
		shaper.rect((float)(xInicio+longitudVida), yInicio,(float) longitudMuerte,BarraVida.altoBarra);
		shaper.setColor(Color.WHITE);
		shaper.end();
	}
}