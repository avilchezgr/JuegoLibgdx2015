package Personaje;

import com.badlogic.gdx.graphics.Texture;

public abstract class Creature {
	protected Texture textura;
	protected float x,y;
}