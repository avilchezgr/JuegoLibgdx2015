package Personaje;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

import Larguia.PantallaJuego;

public class Bruja extends Heroe {
	public final static int offsetArriba = 7;
	public final static int offsetAbajo = 12;
	public final static int radioDisparo = anchoFrame/2;
	//private int damageFlecha = 100;
	public final static int frameDisparo = 5;
	protected boolean primeraVez = true;
	protected int damageTorrentacle = 200;
	public Bruja(float x,float y,String nombre,int nFoto){
		//ancho y alto del frame
				super(x+anchoFrame/2,y+altoFrame/2 - offsetArriba,nombre,nFoto);
				
				velocidadMovimiento = 100;
				super.textura = new Texture("images/"+nFoto+".png");		
				animacion = new AnimacionBruja(this);
				
				anchoReal = 40;
				altoReal = 50;
				rectangle = new Rectangle(x-anchoFrame/2,y-altoFrame/2 + offsetArriba, anchoReal, altoReal);
	}
	@Override
	public void update(PantallaJuego pantallaJuego) {
		// TODO Auto-generated method stub
		boolean torrentacle = isTorrentacle();
		if(torrentacle){
			torrentacle(pantallaJuego);
		}
	}
	private void torrentacle(PantallaJuego pantallaJuego) {
		// TODO Auto-generated method stub
		if(!pantallaJuego.colisionaXY(clickDerechoX, clickDerechoY)){
			Torrentacle torrent = new Torrentacle(this.nombre,(int) clickDerechoX,(int)clickDerechoY,this.damageTorrentacle);
			System.out.println("click derecho x"+clickDerechoX);
			System.out.println("torrent x" +torrent.getX());
			pantallaJuego.addMagia(torrent);
			pantallaJuego.getJuego().getCliente().enviarTorrentacleSerializado(nombre,clickDerechoX,clickDerechoY,torrent.getDamage());

			primeraVez = false;
		}
	}
	private boolean isTorrentacle() {
		// TODO Auto-generated method stub
		boolean animacionTorrentacle = animacion.isAnimacionAccion1();
		boolean isFrameTorrentacle = frameDisparo == animacion.getAnimacionActual().getKeyFrameIndex(animacion.getDuracion());
		//if(isFrameTorrentacle)
		//System.out.println(animacionTorrentacle +" "+isFrameTorrentacle+" "+primeraVez);
		boolean torrentacle = animacionTorrentacle && isFrameTorrentacle && primeraVez;
		return torrentacle;
	}
	@Override
	public void actualizarAnimacionSerializada() {
	
			float duracionAnimacion = animacion.getDuracion();
			int columna= 0;
			if(animacion.isAnimacionMovimientoOCasteo()){
				duracionAnimacion = duracionAnimacion/(animacion.tiempoFrameMovimiento*9);
				columna = (int)(duracionAnimacion / animacion.tiempoFrameMovimiento);
				columna = columna % 9;
				
			}else if(!animacion.isAnimacionMovimientoOCasteo()){
				 columna = animacion.getAnimacionActual().getKeyFrameIndex(duracionAnimacion);
			}
			int fila = -1;
			if(animacion.isAnimacionMovimientoAbajo()){
				fila = 10;
			}else if(animacion.isAnimacionMovimientoArriba()){
				fila = 8;
			}else if(animacion.isAnimacionMovimientoDerecha()){
				fila = 11;
			}else if(animacion.isAnimacionMovimientoIzquierda()){
				fila = 9;
			}else if(animacion.isAnimacionAccion1Arriba()){
				fila = 0;
			}else if(animacion.isAnimacionAccion1Abajo()){
				fila = 2;
			}else if(animacion.isAnimacionAccion1Derecha()){
				fila = 3;
			}else if(animacion.isAnimacionAccion1Izquierda()){
				fila = 1;
			}else if(animacion.isAnimacionMorir()){
				fila = 20;
			}
			//System.out.println("fila "+fila+"columna "+columna);
			serializada.setFila(fila);
			serializada.setColumna(columna);
			serializada.setVida(this.vida);
			
			
		
		
	}
}