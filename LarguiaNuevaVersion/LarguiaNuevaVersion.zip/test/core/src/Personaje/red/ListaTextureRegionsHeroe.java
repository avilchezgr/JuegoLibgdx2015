package Personaje.red;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import Auxiliar.Auxiliar;

import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class ListaTextureRegionsHeroe {
	
	public static final int NUMEROTEXTURAS = 4;
	private LinkedHashMap<Integer,TextureRegionsDeUnPersonaje> mapaTextureRegions;
	
	public ListaTextureRegionsHeroe(int nFrames){
		formarTextureRegions(nFrames);
	}
	
	public void formarTextureRegions(int nFrames){
		mapaTextureRegions = new LinkedHashMap<Integer,TextureRegionsDeUnPersonaje>();
		for(int i = 0; i<nFrames;i++){
			TextureRegionsDeUnPersonaje text = new TextureRegionsDeUnPersonaje(i);
			mapaTextureRegions.put(i, text);
			
		}
		
	}
	public TextureRegion getFrame(int nFoto,int fila,int columna){
		
		return mapaTextureRegions.get(nFoto).getFrame(fila, columna);
	}

	public void dispose() {
		// TODO Auto-generated method stub
		ArrayList<TextureRegionsDeUnPersonaje> valueList = new ArrayList<TextureRegionsDeUnPersonaje>(mapaTextureRegions.values());

		for(int i = 0; i < valueList.size(); i++){
			valueList.get(i).dispose();
			
		}
	}
	
}