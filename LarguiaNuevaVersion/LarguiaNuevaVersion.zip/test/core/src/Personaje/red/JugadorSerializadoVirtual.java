package Personaje.red;

import Personaje.Heroe;

import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;

import Red.Protocolo.Protocolo;

public class JugadorSerializadoVirtual {
	private float x,y;
	private Rectangle rectangle;
	int vida;
	TextureRegion frameActual;
	String nombre;
	private int columna;
	private int fila;
	private int nFoto;
	private BitmapFont graphicsNombre;
	private int expires = 0;
	
	
	public int getColumna() {
		return columna;
	}
	public void setColumna(int columna) {
		this.columna = columna;
	}
	public int getFila() {
		return fila;
	}
	public void setFila(int fila) {
		this.fila = fila;
	}
	public int getnFoto() {
		return nFoto;
	}
	public void setnFoto(int nFoto) {
		this.nFoto = nFoto;
	}
	public JugadorSerializadoVirtual(String nombre,float x,float y,int nFoto,int fila,int columna,int vida){
		this.columna = columna;
		this.fila = fila;
		this.nFoto = nFoto;
		this.vida = vida;
		this.x = x;
		this.y = y;
		rectangle = new Rectangle(x-(Heroe.realAncho/2),y-(Heroe.realAlto/2),Heroe.realAncho,Heroe.realAlto);
		this.nombre = nombre;
		//graphicsNombre=new BitmapFont();
	}
	public float getX() {
		return x;
	}
	public String getNombre(){
		return nombre;
	}
	public void setX(float x) {
		this.x = x;
	}
	public float getY() {
		return y;
	}
	public void setY(float y) {
		this.y = y;
	}
	public Rectangle getRectangle() {
		return rectangle;
	}
	public void setRectangle(Rectangle rectangle) {
		this.rectangle = rectangle;
	}
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public TextureRegion getFrameActual() {
		return frameActual;
	}
	public void setFrameActual(TextureRegion frameActual) {
		this.frameActual = frameActual;
	}
	public void actualizar(String actualizacion) {
		x = Protocolo.getXActualizacion(actualizacion);
		y = Protocolo.getYActualizacion(actualizacion);
		fila = Protocolo.getFilaActualizacion(actualizacion);
		columna = Protocolo.getColumnaActualizacion(actualizacion);
		vida = Protocolo.getVidaActualizacion(actualizacion);
		nFoto = Protocolo.getNFotoActualizacion(actualizacion);
		rectangle.set(x-(Heroe.realAncho/2),y-(Heroe.realAlto/2),Heroe.realAncho,Heroe.realAlto);
		refreshExpires();
	}
	public void dispose() {
		//graphicsNombre.dispose();
		// TODO Auto-generated method stub
		
	}
	public void pintaNombre(SpriteBatch batch){
		graphicsNombre.draw(batch,nombre, (x-(Heroe.anchoFrame/2) )+16, y - (y-(Heroe.altoFrame/2) )+70); // mostrar nombre personaje encima de este.

		
	}
	public float getExpires() {
		// TODO Auto-generated method stub
		return expires;
	}
	public void refreshExpires(){
		expires = 0;
	}
	public void incrementarExpires() {
		expires++;
		// TODO Auto-generated method stub
		
	}
}