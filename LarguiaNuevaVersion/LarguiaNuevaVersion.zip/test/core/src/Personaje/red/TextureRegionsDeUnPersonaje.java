package Personaje.red;

import Auxiliar.Auxiliar;
import Personaje.Heroe;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class TextureRegionsDeUnPersonaje {
	
	private int rutaTextura;
	private Texture textura;
	TextureRegion[][] arrayTextures;
	private TextureRegion[] animacionAndarArriba;
	private TextureRegion[] animacionAndarAbajo;
	private TextureRegion[] animacionAndarDerecha;
	private TextureRegion[] animacionAndarIzquierda;
	
	private TextureRegion[] animacionDispararArriba;
	private TextureRegion[] animacionDispararAbajo;
	private TextureRegion[] animacionDispararDerecha;
	private TextureRegion[] animacionDispararIzquierda;
	
	private TextureRegion[] animacionMagiaBrazosArriba;
	private TextureRegion[] animacionMagiaBrazosAbajo;
	private TextureRegion[] animacionMagiaBrazosDerecha;
	private TextureRegion[] animacionMagiaBrazosIzquierda;
	
	private TextureRegion[] animacionMorir;
	
	public TextureRegionsDeUnPersonaje(int rutaTextura){
		this.rutaTextura = rutaTextura;
		textura = new Texture("images/"+rutaTextura+".png");	
		TextureRegion tRegionAnimacion= new TextureRegion(textura);
		arrayTextures = tRegionAnimacion.split(textura, Heroe.anchoFrame, Heroe.altoFrame);
		
		animacionAndarArriba = Auxiliar.getFilaArrayTextRegion(8,9,arrayTextures);
		animacionAndarAbajo = Auxiliar.getFilaArrayTextRegion(10,9,arrayTextures);
		animacionAndarDerecha = Auxiliar.getFilaArrayTextRegion(11,9,arrayTextures);
		animacionAndarIzquierda = Auxiliar.getFilaArrayTextRegion(9,9,arrayTextures);
		
		//disparar
		
		animacionDispararArriba = Auxiliar.getFilaArrayTextRegion(16,12,arrayTextures);
		animacionDispararAbajo = Auxiliar.getFilaArrayTextRegion(18,12,arrayTextures);
		animacionDispararDerecha = Auxiliar.getFilaArrayTextRegion(19,12,arrayTextures);
		animacionDispararIzquierda = Auxiliar.getFilaArrayTextRegion(17,12,arrayTextures);
		
		//magia brazos arriba
		
		animacionMagiaBrazosArriba = Auxiliar.getFilaArrayTextRegion(0,7,arrayTextures);
		animacionMagiaBrazosIzquierda = Auxiliar.getFilaArrayTextRegion(1,7,arrayTextures);
		animacionMagiaBrazosAbajo = Auxiliar.getFilaArrayTextRegion(2,7,arrayTextures);
		animacionMagiaBrazosDerecha = Auxiliar.getFilaArrayTextRegion(3,7,arrayTextures);
		
		//morir
		animacionMorir = Auxiliar.getFilaArrayTextRegion(20, 6, arrayTextures);
		
		
	}
	TextureRegion getFrame(int fila, int columna){
		TextureRegion[] text = null;
		switch(fila){
		
		case 0:
			text = animacionMagiaBrazosArriba;
			break;
		case 1:
			text = animacionMagiaBrazosIzquierda;
			break;
		case 2:
			text = animacionMagiaBrazosAbajo;
			break;
		case 3:
			text = animacionMagiaBrazosDerecha;
			break;
		case 8:
			text = animacionAndarArriba;
			break;
		case 9:
			text = animacionAndarIzquierda;
			break;
		case 10:
			text = animacionAndarAbajo;
			break;
		case 11:
			text = animacionAndarDerecha;
			break;
		case 16:
			text = animacionDispararArriba;
			break;
		case 17:
			text = animacionDispararIzquierda;
			break;
		case 18:
			text = animacionDispararAbajo;
			break;
		case 19:
			text = animacionDispararDerecha;
			break;
		case 20:
			text = animacionMorir;
		}
		
		return text[columna];
	}
	public void dispose() {
		// TODO Auto-generated method stub
		textura.dispose();
	}
}