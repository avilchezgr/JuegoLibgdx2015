package Personaje.red;

import java.util.ArrayList;
import java.util.LinkedHashMap;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;

import Larguia.PantallaJuego;
import Personaje.BarraVida;
import Personaje.Flecha;
import Personaje.HebraColisionHeroe;
import Personaje.Heroe;
import Personaje.Magia;
import Personaje.Torrentacle;
import Red.FlechaVirtual;
import Red.HebraRecibirActualizaciones;
import Red.MagiaVirtual;
import Red.TorrentacleVirtual;
import Red.Protocolo.Protocolo;
public class GestorJugadoresVirtuales {
	private HebraColisionHeroe hebraColision;
	private HebraRecibirActualizaciones hebraActualiza;
	private LinkedHashMap<String,JugadorSerializadoVirtual> mapaUsuariosVirtuales;
	private PantallaJuego pantallaJuego;
	private ListaTextureRegionsHeroe texturas;
	private ArrayList<FlechaVirtual> listaFlechasVirtuales;
	private ArrayList<MagiaVirtual> listaMagiasVirtuales;
	public GestorJugadoresVirtuales(PantallaJuego pantallaJuego) {
		// TODO Auto-generated constructor stub
		texturas = new ListaTextureRegionsHeroe(ListaTextureRegionsHeroe.NUMEROTEXTURAS);
		this.pantallaJuego = pantallaJuego;
		mapaUsuariosVirtuales = new LinkedHashMap<String,JugadorSerializadoVirtual>();
		hebraColision = new HebraColisionHeroe(this,pantallaJuego.getHeroe());
		listaFlechasVirtuales = new ArrayList<FlechaVirtual>();
		listaMagiasVirtuales = new ArrayList<MagiaVirtual>();
		hebraActualiza = new HebraRecibirActualizaciones(this,pantallaJuego.getJuego().getCliente());
		//hebraColision.start();
		hebraActualiza.start();
	}

	public LinkedHashMap<String,JugadorSerializadoVirtual> getMapaUsuariosVirtuales() {
		// TODO Auto-generated method stub
		return mapaUsuariosVirtuales;
	}
	public boolean existeUsuario(String nombre){
		return mapaUsuariosVirtuales.containsKey(nombre);
	}
	public boolean getColisiona(){
		return hebraColision.getCollides();
	}
	
	public void actualizarUsuario(String nombre,String actualizacion){
		if(existeUsuario(nombre)){
			JugadorSerializadoVirtual jugador = mapaUsuariosVirtuales.get(nombre);
			jugador.actualizar(actualizacion);
		}else{
			mapaUsuariosVirtuales.put(nombre, new JugadorSerializadoVirtual(nombre, 
					Protocolo.getXActualizacion(actualizacion), 
					Protocolo.getYActualizacion(actualizacion),Protocolo.getNFotoActualizacion(actualizacion),
					Protocolo.getFilaActualizacion(actualizacion), Protocolo.getColumnaActualizacion(actualizacion),
					Protocolo.getVidaActualizacion(actualizacion)));
		}
		
	}

	public void pintaBarrasVida(ShapeRenderer shaper) {
		if (mapaUsuariosVirtuales.size() > 0) {
			ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(
					mapaUsuariosVirtuales.values());
			JugadorSerializadoVirtual jugador;
			for (int i = 0; i < valueList.size(); i++) {
				jugador = valueList.get(i);
				BarraVida.dibujarNuevaBarra(jugador.getX(), jugador.getY(),
						jugador.getVida(), shaper);
			}
		}
	}
	public void pintaJugadores(){
		ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(mapaUsuariosVirtuales.values());
	
		SpriteBatch batch = pantallaJuego.getJuego().getBatch();
		batch.begin();
		
		for(int i = 0; i< valueList.size(); i++){
			JugadorSerializadoVirtual jugador = valueList.get(i);
			if(jugador.getExpires()> 120){
				delJugador(jugador.getNombre());
			}else{
				
			TextureRegion text =texturas.getFrame(jugador.getnFoto(), jugador.getFila(), jugador.getColumna());
			batch.draw(text, jugador.getX()-(Heroe.anchoFrame/2), jugador.getY()-(Heroe.altoFrame/2));
			//jugador.pintaNombre(batch);
			jugador.incrementarExpires();
			}
		
		}
		batch.end();
	}

	private void delJugador(String nombre) {
		// TODO Auto-generated method stub
		mapaUsuariosVirtuales.remove(nombre);
	}

	public void dispose() {
		ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(mapaUsuariosVirtuales.values());
		for(int i = 0; i< valueList.size(); i++){
			valueList.get(i).dispose();
			
			
		}
		texturas.dispose();
		// TODO Auto-generated method stub
		
	}

	public PantallaJuego getPantalla() {
		// TODO Auto-generated method stub
		return pantallaJuego;
	}

	public void addFlecha(FlechaVirtual f) {
		listaFlechasVirtuales.add(f);
		
	}
	public void getFlechas(ArrayList<Flecha> listaFlechas){
		if(listaFlechasVirtuales.size()>0){
			listaFlechas.add(new Flecha(listaFlechasVirtuales.get(0),pantallaJuego));
			listaFlechasVirtuales.remove(0);
			getFlechas(listaFlechas);
		}
		
	}
	public void getMagias(ArrayList<Magia> listaMagias){
		if(listaMagiasVirtuales.size()>0){
			if(listaMagiasVirtuales.get(0) instanceof TorrentacleVirtual){
				listaMagias.add(new Torrentacle((TorrentacleVirtual) listaMagiasVirtuales.get(0),
						this.pantallaJuego));
				listaMagiasVirtuales.remove(0);
				getMagias(listaMagias);
			}
		}
	}
	public boolean getNextColisiona(float x, float y) {
		// TODO Auto-generated method stub
		
	
		boolean value = false;
		if(this.mapaUsuariosVirtuales != null && this.mapaUsuariosVirtuales.size() > 0){
		Rectangle rect = new Rectangle(x-(Heroe.realAncho/2),y-(Heroe.realAlto/2),Heroe.realAncho,Heroe.realAlto);
		ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(mapaUsuariosVirtuales.values());
		for(int i = 0; i< valueList.size(); i++){
			value = valueList.get(i).getRectangle().overlaps(rect);
			if(value == true){
				
				break;
			}
			
		}
		}
		return value;
	}

	public boolean getColisionaFlecha(float x, float y) {
		// TODO Auto-generated method stub
		boolean value = false;
		if(this.mapaUsuariosVirtuales != null && this.mapaUsuariosVirtuales.size() > 0){
			Rectangle rect = new Rectangle((x-1),(y-1),2,2);
			ArrayList<JugadorSerializadoVirtual> valueList = new ArrayList<JugadorSerializadoVirtual>(mapaUsuariosVirtuales.values());
			for(int i = 0; i < valueList.size(); i++){
				value = valueList.get(i).getRectangle().overlaps(rect);
				if (value){
					break;
				}
			}
			
		}
		return value;
		
	}

	public void addTorrentacle(TorrentacleVirtual t) {
		// TODO Auto-generated method stub
		System.out.println("torrentacle added");
		listaMagiasVirtuales.add(t);
	}
}