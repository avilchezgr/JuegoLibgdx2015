package Input;

import com.badlogic.gdx.Gdx;

public class ControladorEntrada {

	//estados
	private int ultimaDireccion;
	
	public final static int direccionArriba = 0;
	public final static int direccionAbajo = 1;
	public final static int direccionIzquierda = 2;
	public final static int direccionDerecha = 3;
	
	public final static int iAccion1Arriba = 4;
	public final static int iAccion1Abajo = 5;
	public final static int iAccion1Izquierda = 6;
	public final static int iAccion1Derecha = 7;
	
	public final static int iAccion2Arriba = 8;
	public final static int iAccion2Abajo = 9;
	public final static int iAccion2Izquierda = 10;
	public final static int iAccion2Derecha = 11;
	
	
	
	
	
	private boolean moverDerecha;
	private boolean moverIzquierda;
	private boolean moverArriba;
	private boolean moverAbajo;
	
	//private boolean accion1Derecha;
	//private boolean accion1Izquierda;
	private boolean accion1Arriba;// = true; //CAMBIAR
	//private boolean accion1Abajo;
	
	private boolean accion2Derecha;
	private boolean accion2Izquierda;
	private boolean accion2Arriba;
	private boolean accion2Abajo;

	private int clickDerechoX=0;//350; //CAMBIAR

	private int clickDerechoY=0;//270; //CAMBIAR

	private boolean space;
	
	
	
	//private int velocidad;
	
	public ControladorEntrada(){
		
		ultimaDireccion = direccionAbajo;
		
		moverDerecha = false;
		moverIzquierda = false;
		moverArriba = false;
		moverAbajo = false;
		
		//accion1Derecha = false;
		//accion1Izquierda = false;
		accion1Arriba = false;
		//accion1Abajo = false;
		
		accion2Derecha = false;
		accion2Izquierda = false;
		accion2Arriba = false;
		accion2Abajo = false;
	}
	
	
	public void desactivarDirecciones(){
		setMoverDerecha(false);
		setMoverIzquierda(false);
		setMoverArriba(false);
		setMoverAbajo(false);
		
	}
	public void desactivarAcciones(){
		
		desactivarAccion1();
		desactivarAccion2();

	}
	public void desactivarAccion1(){
		
		//accion1Izquierda = false;
		//accion1Derecha = false;
		accion1Arriba = false;
		//accion1Abajo = false;
		
	}
	public void desactivarAccion2(){
		
		accion2Izquierda = false;
		accion2Derecha = false;
		accion2Arriba = false;
		accion2Abajo = false;
		
	}
	public boolean getMoverDerecha(){
		return moverDerecha;
	}

	public boolean getMoverArriba() {
		return moverArriba;
	}

	public boolean getMoverIzquierda() {
		return moverIzquierda;

	}

	public boolean getMoverAbajo() {
		return moverAbajo;

	}

	public void setMoverDerecha(boolean m) {
		moverDerecha=m;
	}

	public void setMoverIzquierda(boolean m) {
		moverIzquierda=m;
	}

	public void setMoverArriba(boolean m) {
		moverArriba=m;

	}

	public void setMoverAbajo(boolean m) {
		moverAbajo=m;

	}
	
	
public void setAccion2(){
		
		if(moverDerecha){
			
			accion2Derecha=true;
			accion2Izquierda=false;
			accion2Arriba=false;
			accion2Abajo=false;
			
		}else if(moverIzquierda){
			
			accion2Derecha=false;
			accion2Izquierda=true;
			accion2Arriba=false;
			accion2Abajo=false;
		
		}else if(moverArriba){
			
			accion2Derecha=false;
			accion2Izquierda=false;
			accion2Arriba=true;
			accion2Abajo=false;
			
		}else if(moverAbajo){
			
			accion2Derecha=false;
			accion2Izquierda=false;
			accion2Arriba=false;
			accion2Abajo=true;
			
		}
		
	}

	public void setAccion1(){
		
		accion1Arriba = true;
		
	}
	/**@version anterior
	public void setAccion1(){
		
		if(ultimaDireccion == direccionDerecha){
			System.out.println("derecha");
			accion1Derecha=true;
			accion1Izquierda=false;
			accion1Arriba=false;
			accion1Abajo=false;
			
		}else if(ultimaDireccion == direccionIzquierda){
			
			accion1Derecha=false;
			accion1Izquierda=true;
			accion1Arriba=false;
			accion1Abajo=false;
			
		}else if(ultimaDireccion == direccionArriba){
			
			accion1Derecha=false;
			accion1Izquierda=false;
			accion1Arriba=true;
			accion1Abajo=false;
			
		}else if(ultimaDireccion == direccionAbajo){
			//System.out.println()
			accion1Derecha=false;
			accion1Izquierda=false;
			accion1Arriba=false;
			accion1Abajo=true;
			
		}
		
	}
**/
	public boolean isAccion1() {

		
				
		return accion1Arriba;
	}

	

	public boolean isAccion1Arriba() {
		return accion1Arriba;
	}
	
	public boolean isAccion2Derecha() {
		return accion2Derecha;
	}
	public boolean isAccion2Izquierda() {
		return accion2Izquierda;
	}
	public boolean isAccion2Arriba() {
		return accion2Arriba;
	}
	public boolean isAccion2Abajo() {
		return accion2Abajo;
	}
	public boolean isAccion2() {

		boolean accion2 = accion2Derecha || accion2Izquierda || accion2Arriba
				|| accion2Abajo;
		return accion2;
	}
	public void setUltimaDireccion(int direccion){
		
		this.ultimaDireccion=direccion;
		
	}
	public int getUltimaDireccion(){

		return ultimaDireccion;
	}

	/**
	 * 
	 * Actualmente recibe la posicion x e y del heroe y calcula si esta a
	 * -45<angulo<45 o si 45< angulo<135 o si 135<angulo < 225 en cada caso
	 * elige una animacion de disparo distinta
	 * 
	 * Metodo que habria que cambiar para cambiar la decision de que animacion
	 * coger dependiendo de la posicion etc
	 * 
	 * 
	 * */
	public int getAccionPulsada(float x, float y) {

		int valor = -1;
		if (hayAccionActivada()) {

			double u1 = x + 3;
			double u2 = 0;
			double v1 = clickDerechoX - x;
			double v2 = clickDerechoY - y;
			double numerador = (u1 * v1) + (u2 * v2);
			double denominador = Math.sqrt((u1 * u1) + (u2 * u2))
					* Math.sqrt((v1 * v1) + (v2 * v2));

			double coseno = numerador / denominador;
			double angulo = Math.acos(coseno);// =
												// Math.acos(numerador/denominador);

			// System.out.println((clickDerechoX - x) + "," + (clickDerechoY - y));
		//	System.out.println((Math.acos(numerador / denominador) * 180)
				//	/ Math.PI);

			// if(clickDerechoY > y ){

			if (angulo > -(Math.PI / 4) && angulo <= Math.PI / 4) {// animacion
																	// derecha
			//	System.out.println("angulo cuadrante a");
				valor = iAccion1Derecha;
			} else if (angulo > (Math.PI / 4) && angulo <= (3 * Math.PI / 4)
					&& clickDerechoY > y) {// animacion arriba
				valor = iAccion1Arriba;
				//System.out.println("angulo cuadrante b");

			} else if (angulo > (3 * Math.PI / 4)
					&& angulo <= (5 * Math.PI / 4)) {// animacion izquierda
				valor = iAccion1Izquierda;
				//System.out.println("angulo cuadrante c");
				// }else if(angulo > (5*Math.PI/4) && angulo <= Math.PI/4){

				// System.out.println("angulo cuadrante d");
			} else { // animacion abajo
				valor = iAccion1Abajo;
			//	System.out.println("angulo cuadrantee d");
			}
		} else if (moverDerecha || moverIzquierda || moverArriba || moverAbajo) {
			if (moverDerecha) {
				valor = direccionDerecha;
			} else if (moverIzquierda) {
				valor = direccionIzquierda;
			} else if (moverArriba) {
				valor = direccionArriba;
			} else if (moverAbajo) {
				valor = direccionAbajo;
			}

		}
		return valor;
	}
/***@version anterior
	public int getAccionPulsada(float x, float y){ //cambiar
		int valor = -1;
		boolean direcciones = moverDerecha
				|| moverIzquierda
				|| moverArriba || moverAbajo;
		boolean acciones = isAccion1() || isAccion2();
		
		if(acciones){
			if(accion1Derecha){
				valor = iAccion1Derecha;
			}
			else if(accion1Izquierda){
				valor = iAccion1Izquierda;
			}
			else if(accion1Arriba){
				valor = iAccion1Arriba;
			}else if(accion1Abajo){
				valor = iAccion1Abajo;
			} 
			else if(accion2Derecha){
				valor = iAccion2Derecha;
			}
			else if(accion2Izquierda){
				valor = iAccion2Izquierda;
			}
			else if(accion2Arriba){
				valor = iAccion2Arriba;
			}else if(accion2Abajo){
				valor = iAccion2Abajo;
			}
			
		}else if (direcciones){
			if(moverDerecha){
				valor = direccionDerecha;
			}else if(moverIzquierda){
				valor = direccionIzquierda;
			}else if(moverArriba){
				valor = direccionArriba;
			}else if(moverAbajo){
				valor = direccionAbajo;
			}
			
		}
		
		return valor;
	}
	**/
	
	public boolean hayTeclaActivada() {
		
		return hayDireccionActivada() || hayAccionActivada();
	}
	public boolean hayDireccionActivada(){
		
		boolean direcciones = moverDerecha
				|| moverIzquierda
				|| moverArriba || moverAbajo;
		return direcciones;
	}
	public boolean hayAccionActivada(){
		
		boolean acciones = isAccion1() || isAccion2();
		
		return acciones;
	}


	public void setClickDerechoX(int screenX) {
		// TODO Auto-generated method stub
		clickDerechoX = screenX;
	}


	public void setClickDerechoY(int screenY) {
		// TODO Auto-generated method stub
		clickDerechoY = screenY;
	}


	public int getClickDerechoX() {
		return clickDerechoX;
	}


	public int getClickDerechoY() {
		return clickDerechoY;
	}


	public void setSpace(boolean b) {
		space = b;
		// TODO Auto-generated method stub
		
	}


	public boolean isSpace() {
		// TODO Auto-generated method stub
		return space;
	}
	

}