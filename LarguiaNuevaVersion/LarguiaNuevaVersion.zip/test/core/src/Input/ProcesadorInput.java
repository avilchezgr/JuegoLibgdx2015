package Input;

import Auxiliar.Punto;
import Larguia.Pantalla;
import Larguia.PantallaJuego;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.math.Vector3;


public class ProcesadorInput extends InputAdapter {
	
	ControladorEntrada controlador;
	PantallaJuego pantalla;
	public ProcesadorInput(ControladorEntrada controlador,PantallaJuego pantalla){
		this.pantalla = pantalla;
		this.controlador=controlador;
	}
	
	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub
		switch (keycode) {
		case Input.Keys.LEFT:
		case Input.Keys.A:
		//	if (!controlador.getMoverDerecha())
				controlador.setMoverDerecha(false);
				controlador.setMoverIzquierda(true);
				controlador.setUltimaDireccion(ControladorEntrada.direccionIzquierda);
			return true;
		case Input.Keys.RIGHT:
		case Input.Keys.D:
			//if (!controlador.getMoverIzquierda())
				controlador.setMoverIzquierda(false);
				controlador.setMoverDerecha(true);
				controlador.setUltimaDireccion(ControladorEntrada.direccionDerecha);
			return true;
		case Input.Keys.UP:
		case Input.Keys.W:
			//if (!controlador.getMoverAbajo())
				controlador.setMoverAbajo(false);
				controlador.setMoverArriba(true);
				controlador.setUltimaDireccion(ControladorEntrada.direccionArriba);
				
			return true;
		case Input.Keys.DOWN:
		case Input.Keys.S:
			//if (!controlador.getMoverArriba())
				controlador.setMoverArriba(false);
				controlador.setMoverAbajo(true);
				controlador.setUltimaDireccion(ControladorEntrada.direccionAbajo);
			return true;
		case Input.Keys.SPACE:
		//	controlador.setSpace(true);
			//System.out.println("accion");
			//controlador.setAccion1();
			return true;
	//	case Input.Keys.E:
		//	controlador.setAccion2();
			// return true;
		default:
			return false;
		}
		
		
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		switch (keycode) {
		case Input.Keys.LEFT:
		case Input.Keys.A:
			
				controlador.setMoverIzquierda(false);
			return true;
		case Input.Keys.RIGHT:
		case Input.Keys.D:
				
				controlador.setMoverDerecha(false);
			return true;
		case Input.Keys.UP:
		case Input.Keys.W:
		
				controlador.setMoverArriba(false);
			return true;
		case Input.Keys.DOWN:
		case Input.Keys.S:
			
				controlador.setMoverAbajo(false);
			return true;
		
		case Input.Keys.Q:
			
			//controlador.desactivarAcciones();
			return true;
		case Input.Keys.E:
			//controlador.desactivarAcciones();
			return true;
		//case Input.Keys.SPACE:
		//	controlador.desactivarAccion1();
		//	return true;
		default:
			return false;
		}
		
		
	}
	
	@Override
	public boolean touchDown (int screenX, int screenY, int pointer, int button) {
		//System.out.println("hola");
		if(button == Input.Buttons.LEFT){
			Vector3 worldCoordinates = new Vector3(screenX, screenY, 0);
			pantalla.getCamera().unproject(worldCoordinates);
			
		System.out.println("posicion click "+Math.round(worldCoordinates.x)+","+Math.round(worldCoordinates.y));
		
		//System.out.println(worldCoordinates.x+","+worldCoordinates.y);
		}
		if(button == Input.Buttons.RIGHT){
			
		
			
		
			Vector3 worldCoordinates = new Vector3(screenX, screenY, 0);
			pantalla.getCamera().unproject(worldCoordinates);
			if(worldCoordinates.x > 0 &&  worldCoordinates.y > 0){
			controlador.setAccion1();
			//controlador.setClickDerechoX(screenX);
			//controlador.setClickDerechoY(Gdx.graphics.getHeight() - screenY);
			controlador.setClickDerechoX(Math.round(worldCoordinates.x));
			controlador.setClickDerechoY(Math.round(worldCoordinates.y));
			}
		}
		return false;
	}
	
	public Punto convertirACoordAbsolutas(int screenX,int screenY){
		float x = pantalla.getHeroe().getX();
		float y = pantalla.getHeroe().getY();
		//if(screenX-x)
		return null;
	}
	
	@Override
	public boolean touchUp (int screenX, int screenY, int pointer, int button) {
		//System.out.println("hola");
		if(button == Input.Buttons.RIGHT){
			controlador.desactivarAccion1();
			
		}
		return false;
	}
	
	
}