package Red;

public class ActualizacionHeroe {
	
	float x,y;
	int id;
	
}