package Red;

public class MagiaVirtual {
	protected String nombre;
	protected float x,y;
	//private float objX,objY;
	//private int tipo;
	protected int damage;
	//private float angulo;
	public String getNombre() {
		return nombre;
	}
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	
	
	public int getDamage() {
		return damage;
	}
	
}