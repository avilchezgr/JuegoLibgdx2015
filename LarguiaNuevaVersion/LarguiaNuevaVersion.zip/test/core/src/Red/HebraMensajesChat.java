package Red;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;

public class HebraMensajesChat extends Thread{
	
	BufferedReader in;
	PrintWriter out;
	Socket socket;
	
	public HebraMensajesChat(Socket socket, BufferedReader in, PrintWriter out){
		this.in = in;
		this.out = out;
		this.socket = socket;
	}
	
	@Override
	public void run(){
		
		
	}
}