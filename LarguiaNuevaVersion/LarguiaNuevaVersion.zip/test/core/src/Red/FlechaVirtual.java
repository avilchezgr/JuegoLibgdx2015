package Red;

public class FlechaVirtual {
	private String nombre;
	private float x,y;
	private float objX,objY;
	private int tipo;
	private int damage;
	private float angulo;
	public String getNombre() {
		return nombre;
	}
	public float getX() {
		return x;
	}
	public float getY() {
		return y;
	}
	public float getObjX() {
		return objX;
	}
	public float getObjY() {
		return objY;
	}
	public int getTipo() {
		return tipo;
	}
	public int getDamage() {
		return damage;
	}
	public float getAngulo() {
		return angulo;
	}
	public FlechaVirtual(String nombre,float x,float y,float objX,float objY, int tipo, int damage,float angulo){
		this.nombre = nombre;
		this.x = x;
		this.y = y;
		this.angulo = angulo;
		this.objX = objX;
		this.objY = objY;
		this.tipo = tipo;
		this.damage = damage;
		
	}
}