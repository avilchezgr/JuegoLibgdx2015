package Red;

public class HebraEnviarActualizaciones extends Thread{

}