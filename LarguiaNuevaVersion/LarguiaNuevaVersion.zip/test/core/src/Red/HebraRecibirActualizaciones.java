package Red;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

import Personaje.Flecha;
import Personaje.red.GestorJugadoresVirtuales;
import Red.Protocolo.Protocolo;
import Auxiliar.Util;
public class HebraRecibirActualizaciones extends Thread {
	private GestorJugadoresVirtuales gestorJugadores;
	private Cliente cliente;
	private DatagramSocket socketUDP;
	public HebraRecibirActualizaciones(GestorJugadoresVirtuales gestor, Cliente cliente) {
		this.gestorJugadores = gestor;
		this.cliente = cliente;
		socketUDP = cliente.getSocketUdp();
	}

	public void run() {
		while (true) {
			DatagramPacket p = new DatagramPacket(new byte[Cliente.MAXSIZEUDP],
					Cliente.MAXSIZEUDP);
			try {
				socketUDP.receive(p);
				byte[] bytes = p.getData();
				String data = Util.openFileToString(bytes);
				//System.out.println(data);
				if (Protocolo.getCabecera(data).equals(Protocolo.cabAct)) {
					
					//System.out.println(data);
					String nombre = Protocolo.getNombreActualizacion(data);
					if (!nombre.equals(cliente.getNombre())) {

						actualizarJugador(nombre, data);
						//System.out.println("asdf");
					}
				}else if(Protocolo.getCabecera(data).equals(Protocolo.cabFlecha) && !Protocolo.getNombreFlecha(data).equals(cliente.getNombre())){ //mensaje flecha
					gestorJugadores.addFlecha(formarFlecha(data));
				}
				else if(Protocolo.getCabecera(data).equals(Protocolo.cabTorrentacle) && !Protocolo.getNombreTorrentacle(data).equals(cliente.getNombre())){ //mensaje torrentacle
					System.out.println("torrentacle add");
					gestorJugadores.addTorrentacle(formarTorrentacle(data));
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.err
						.println("MUY GRAVE, PROBLEMA CON EL SOCKET QUE RECIBE ACTUALIZACIONES");
			}

		}
	}
	public FlechaVirtual formarFlecha(String data){
		return new FlechaVirtual(Protocolo.getNombreFlecha(data),Protocolo.getXInicialFlecha(data),Protocolo.getYInicialFlecha(data),Protocolo.getXObjFlecha(data),Protocolo.getYObjFlecha(data),Protocolo.getDireccionFlecha(data),Protocolo.getDamageFlecha(data),Protocolo.getAnguloFlecha(data));
	}
	public TorrentacleVirtual formarTorrentacle(String data){
		return new TorrentacleVirtual(Protocolo.getNombreTorrentacle(data),Protocolo.getXTorrentacle(data),Protocolo.getYTorrentacle(data),Protocolo.getDamageTorrentacle(data));
	}
	public void actualizarJugador(String nombre,String mensaje){
		gestorJugadores.actualizarUsuario(nombre, mensaje);
		
	}
}