package Red;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import Personaje.AnimacionSerializada;
import Personaje.Arquero;
import Personaje.Flecha;
import Red.Protocolo.Protocolo;
import Auxiliar.Auxiliar;
public class Cliente {
	public final static int nDecimales = 2;
	public final static int MAXSIZEUDP = 55;
	public final static int puertoMinUDP = 5000;
	public final static int puertoMaxUDP = 6000;
	//public final static String direccionUDP = "localhost"; 
	//public final static String direccion = "192.168.0.199";
	public final static String direccionServidor ="192.168.0.198";
	public final static int puertoServidorUDP = 9000;
	public final static int puertoTCP = 8888;
	private int puertoUDP;
	private DatagramSocket socketUdp;
	private Socket socket;
	private BufferedReader in;
	private PrintWriter out;
	
	private int id;
	private float posX;
	private float posY;
	private int nFoto;
	
	//HebraRecibirActualizaciones hebraRA;
	HebraEnviarActualizaciones hebraEA;
	HebraMensajesChat hebraM;
	
	public DatagramSocket getSocketUdp() {
		return socketUdp;
	}

	public void setSocketUdp(DatagramSocket socketUdp) {
		this.socketUdp = socketUdp;
	}

	String nombre;
	String clave;
	
	public static final int estadoNoIniciado = 0;
	public static final int estadoErrorHostDesconocido = 400;
	public static final int estadoErrorIOException = 401;
	public static final int estadoConexionRealizadaConExito = 200;
	public static final int estadoLoginIncorrecto = 402;
	public int estado;
	private int tipoPersonaje;
	
	
	
	public Cliente(String nombre,String clave){
		this.nombre = nombre;
		this.clave = clave;
		setEstado(estadoNoIniciado);
		puertoUDP = Auxiliar.randInt(puertoMinUDP, puertoMaxUDP);
		System.out.println("Puerto UDP " + puertoUDP);
	}
	
	/**
	 * Devuelve 1 para conexion correcta, 0 para error de conexión
	 * */
	public int iniciarConexion(){
		try {
			socket = new Socket (direccionServidor,puertoTCP);
			out= new PrintWriter(socket.getOutputStream(), true);
            in=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            boolean loginCorrecto = loguear();
            if(loginCorrecto){
            	setEstado(estadoConexionRealizadaConExito);
            	
            	socketUdp = new DatagramSocket(puertoUDP);//,InetAddress.getByName(direccionUDP));
            	
            	hebraM = new HebraMensajesChat(socket, in, out);
            	 hebraM.start();
            	 
            }else{
            	setEstado(estadoLoginIncorrecto);
            	
            }
			return 1;
		} catch (UnknownHostException e) {
			setEstado(estadoErrorHostDesconocido);
			// TODO Auto-generated catch block
			
			e.printStackTrace();
			return 0;
		} catch (IOException e) {
			setEstado(estadoErrorIOException);
			// TODO Auto-generated catch block
			e.printStackTrace();
			return 0;
		}
		
	}
	
	public boolean loguear() throws IOException{
		boolean loginCorrecto = false;
		out.println(Protocolo.mensajeIdentificacionCliente(nombre,clave,puertoUDP));
		out.flush();
		String respuesta = in.readLine();
		if(Protocolo.identificarMensajeCliente(respuesta) == Protocolo.mensajeConexionOK){
			loginCorrecto = true;
			String palabras[] = respuesta.split(Protocolo.sp);
			id = Integer.parseInt(palabras[1]);
			posX = Float.parseFloat(palabras[2]);
			posY = Float.parseFloat(palabras[3]);
			nFoto = Integer.parseInt(palabras[4]);
			tipoPersonaje = Integer.parseInt(palabras[5]);
			System.out.println("Login correcto");
		}
		return loginCorrecto;
	}
	public void setEstado(int nuevoEstado){
		estado = nuevoEstado;
	}
	public int getEstado(){
		return estado;
	}
	public int getTipoPersonaje(){
		return tipoPersonaje;
	}
	public void enviarActualizacion(AnimacionSerializada serializada){
		byte[] mensaje = serializada.formarMensajeActualizacion();
		try {
			DatagramPacket dato = new DatagramPacket(mensaje,mensaje.length,InetAddress.getByName(direccionServidor),puertoServidorUDP);
			socketUdp.send(dato);
			//System.out.println(dato.getAddress().getHostAddress());
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	public float getX() {
		// TODO Auto-generated method stub
		return posX;
	}

	public float getY() {
		// TODO Auto-generated method stub
		return posY;
	}
	public int getNFoto(){
		return nFoto;
	}


	public void setX(float x) {
		this.posX = x;
	}



	public void setY(float y) {
		this.posY = y;
	}

	public String getNombre() {
		// TODO Auto-generated method stub
		return nombre;
	}

	public void enviarFlechaSerializada(Arquero arquero, float xInicial,
			float yInicial, float xObj, float yObj,
			int direccion, int damage, float angulo) {
		
		String mFlecha = Protocolo.generarFlecha(arquero.getNombre(),Auxiliar.round(xInicial,nDecimales),Auxiliar.round(yInicial,nDecimales),Auxiliar.round(xObj,nDecimales),Auxiliar.round(yObj,nDecimales),direccion,damage,angulo);
		byte[] data = mFlecha.getBytes();
		DatagramPacket p;
		try {
			p = new DatagramPacket(data,data.length,InetAddress.getByName(direccionServidor),puertoServidorUDP);
			socketUdp.send(p);
		//	
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void enviarTorrentacleSerializado(String nombre, float xInicial,
			float yInicial,int damage) {
		
		String mFlecha = Protocolo.generarTorrentacle(nombre,Auxiliar.round(xInicial,nDecimales),Auxiliar.round(yInicial,nDecimales),damage);
		byte[] data = mFlecha.getBytes();
		DatagramPacket p;
		try {
			p = new DatagramPacket(data,data.length,InetAddress.getByName(direccionServidor),puertoServidorUDP);
			socketUdp.send(p);
		//	
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}