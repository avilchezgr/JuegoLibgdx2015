package Red;

public class TorrentacleVirtual extends MagiaVirtual {
	
	public TorrentacleVirtual(String nombre,float x,float y, int damage){
		
		this.nombre = nombre;
		this.x = x;
		this.y = y;
		this.damage = damage;
		
	}
}