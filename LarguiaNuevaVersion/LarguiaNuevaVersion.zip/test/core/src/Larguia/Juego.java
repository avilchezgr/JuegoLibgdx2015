package Larguia;

import Red.Cliente;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Juego extends Game {
	private SpriteBatch batch;
	
	
	private int height;
	private int width;
	private Pantalla pantallaJuego;
	private Pantalla pantallaMenu;
	private Cliente cliente;
	private Sound disparo;
	private boolean sonidoActivado = false;
	//private BitmapFont mensaje;
	
	//PRUEBAS
	private Pantalla pantallaMapa;

	private String nombre;
	

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public void create () {
		
		disparo = Gdx.audio.newSound(Gdx.files.internal("disparo.wav"));
		batch = new SpriteBatch();
		
		Gdx.graphics.setDisplayMode(840, 620, false);
		height = Gdx.graphics.getHeight();
		width = Gdx.graphics.getWidth();
		pantallaJuego = new PantallaJuego(this);
		//pantallaMapa = new PantallaMapa(this);
		pantallaMenu = new PantallaMenu(this);
		setScreen(pantallaMenu);
		//setScreen(pantallaMapa);
	}

	//1 18
	public void reproducirDisparo(){
		if(sonidoActivado)
		disparo.play();
	}
	public void dispose(){
		
		super.dispose();
		batch.dispose();
		disparo.dispose();
		//img.dispose();
	}
	public SpriteBatch getBatch(){
		
		return batch;
	}
	public int getHeight(){
		return height;
	}
	
	public int getWidth(){
		return width;
	}
	public void setCliente(Cliente cliente){
		this.cliente = cliente;
	}
	public Cliente getCliente(){
		return cliente;
	}

	public Screen getPantallaJuego() {
		// TODO Auto-generated method stub
		return pantallaJuego;
	}
}