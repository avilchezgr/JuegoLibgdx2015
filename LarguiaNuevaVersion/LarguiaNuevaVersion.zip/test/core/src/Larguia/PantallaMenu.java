package Larguia;

//import javafx.scene.text.Text;
import Red.Cliente;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Event;
import com.badlogic.gdx.scenes.scene2d.EventListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.Table.Debug;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.Align;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;

public class PantallaMenu extends Pantalla {
	 private Stage stage;
	 private Skin skin;
	 private Table table;
	 private ShapeRenderer shapeRenderer;
	 private Sprite spriteFondo;
	 Texture textureFondo;
	 
	 TextField campoLogin;
	 TextField campoPassword;
	 TextButton button;
	 
	public PantallaMenu(final Juego juego) {
		super(juego);

		textureFondo = new Texture("ui/fondo.jpg");
		spriteFondo = new Sprite(textureFondo);
		
		
		stage = new Stage();
		shapeRenderer = new ShapeRenderer();
		skin = new Skin(Gdx.files.internal("ui/uiskin.json"));
		table = new Table();
		table.setFillParent(true);
		stage.addActor(table);
	
		Label labelBienvenido = new Label("BIENVENIDO A LARGUIA", skin);
		labelBienvenido.setFontScale(3, 3);
		
		Label labelLogin = new Label("Introduce Login",skin);
		Label labelPassword = new Label("Introduce Password",skin);
		campoLogin = new TextField("",skin);
		campoPassword = new TextField("",skin);
		campoPassword.setPasswordCharacter('*');
		campoPassword.setPasswordMode(true);
		button = new TextButton("Entrar al Mundo",skin);
		button.setSize(500, 30);
		//button.setPosition(50, 50);
		
		table.add(labelBienvenido).colspan(2).expand();
		//table.add(labelBienvenido).colspan(3);
		table.row();
		table.row();
		table.add(labelLogin).width(200).height(100).right();
		table.add(campoLogin).width(300).left();
		table.row();
		table.add(labelPassword).width(200).height(100).right();
		table.add(campoPassword).width(300).left();
		
		table.row();
		table.add(button).align(Align.center).colspan(2).expand().fill(0.3f, 0.3f);
		//table.debug();
		stage.addActor(table);
		Gdx.input.setInputProcessor(stage);
		//table.debugAll();
		//table.debug();
		 

		button.setBounds(button.getOriginX(), button.getOriginY(), button.getWidth(), button.getHeight());
		button.addListener(new ChangeListener(){

			@Override
			public void changed(ChangeEvent event, Actor actor) {
				// TODO Auto-generated method stub
				button.setText("Conectando...");
				System.out.println("haciendo cosas");
				String login = campoLogin.getText();
				String password = campoPassword.getText();
				Cliente cliente = new Cliente(login,password);
				cliente.iniciarConexion();
				if(cliente.getEstado() == Cliente.estadoConexionRealizadaConExito){
					button.setText("Conectado");
					juego.setCliente(cliente);
					//juego.setX(cliente.getX());
					//juego.setY(cliente.getY());
					//juego.setNFoto()
					//System.out.println(juego.getX()+" "+juego.getY());
					juego.setScreen(juego.getPantallaJuego());
				}else if(cliente.getEstado() == Cliente.estadoLoginIncorrecto){
					button.setText("Usuario Incorrecto");
				}
			//	campoPassword.
			}
			
			
		});
		/**button.addListener(new EventListener() {
		    public boolean touchDown (InputEvent event, float x, float y, int pointer, int button) {
		        System.out.println("down");
		        return true;
		    }

		    public void touchUp (InputEvent event, float x, float y, int pointer, int button) {
		        System.out.println("up");
		    }

			@Override
			public boolean handle(Event event) {
				// TODO Auto-generated method stub
				return false;
			}
		});
		**/
		
		
		
		
		
		
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	@Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0.2f, 0.2f, 0.2f, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        
        juego.getBatch().begin();
        spriteFondo.draw(juego.getBatch());
        juego.getBatch().end();
        
        stage.draw();
        stage.act(delta);
   
    }
	@Override
    public void show() {
    }

    @Override
    public void hide() {
        dispose();
    }

   @Override
   public void pause() {
   }

   @Override
   public void resume() {
   }

   @Override
   public void dispose() {
       stage.dispose();
       shapeRenderer.dispose();
       textureFondo.dispose();
   }
}
