package Larguia;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import Input.ControladorEntrada;
import Input.ProcesadorInput;
import Personaje.AnimacionHeroe;
import Personaje.Arquero;
import Personaje.BarraVida;
import Personaje.Bruja;
import Personaje.Heroe;
import Personaje.Flecha;
import Personaje.Magia;
import Personaje.red.GestorJugadoresVirtuales;
import Personaje.red.JugadorSerializadoVirtual;
import Red.Protocolo.Protocolo;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;


public class PantallaJuego extends Pantalla {
	private Heroe heroe;
	//private Map<Flecha,Flecha>  mapaFlechas;
	private List<Flecha> arrayFlechas;
	List<Magia> arrayMagias;
	//private Sprite sprite;
	private ControladorEntrada controlador;
	private ProcesadorInput input;
	//private Texture texturaFondo;
	private BitmapFont indicadorPosicionHeroe;
	private BitmapFont indicadorFramesPorSegundo;
	
	//TUTORIAL CAMARA LIBGDX
	private ShapeRenderer shaper;
	private OrthographicCamera camera;
	private float posInicialHeroeX;
	private float posInicialHeroeY;
	//FIN CAMARA
	
	
	//float delta; //tiempo que ha pasado desde la anterior recarga de pantalla
	
	
	//Animation animacionActualJugador;
	
	//TILEDMAP
	private TiledMap mapa;
	private OrthogonalTiledMapRenderer mapRenderer;
	private TiledMapTileLayer collisionLayer;
	private int capaQueColisiona = 1;
	
	//FIN TILEDMAP
	GestorJugadoresVirtuales gestorJugadores;
	
	public PantallaJuego(Juego juego){
		super(juego);
		
	//	System.out.println("creando pantalla");
		
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		//POSICION DEL HEROE Y CREACION DEL HEROE
				//posInicialHeroeX = Gdx.graphics.getWidth()/2-Heroe.anchoFrame/2;
				//posInicialHeroeY = Gdx.graphics.getHeight()/2-Heroe.altoFrame/2;
				//posInicialHeroeX = 300;
				//posInicialHeroeY = 200;
				posInicialHeroeX = juego.getCliente().getX();
				posInicialHeroeY = juego.getCliente().getY();
				int nFoto = juego.getCliente().getNFoto();
				String nombre = juego.getCliente().getNombre();
				switch(juego.getCliente().getTipoPersonaje()){
				case Heroe.tipoArquero:
					heroe=new Arquero(posInicialHeroeX,posInicialHeroeY,nombre,nFoto);

					break;
				case Heroe.tipoBruja:
					heroe = new Bruja(posInicialHeroeX,posInicialHeroeY,nombre,nFoto);
					break;
				}
		
				gestorJugadores = new GestorJugadoresVirtuales(this);
				
		//CREAMOS CAMARA
		//camera = new OrthographicCamera((posInicialHeroeX+Gdx.graphics.getWidth())/2,(posInicialHeroeY+Gdx.graphics.getHeight())/2);
		camera = new OrthographicCamera(Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
		
		
		
		//camera = new OrthographicCamera(posInicialHeroeX,posInicialHeroeY);
		camera.update();
		shaper = new ShapeRenderer();
		
		//CREAMOS FLECHAS
		arrayFlechas = new ArrayList<Flecha>();
		arrayMagias = new ArrayList<Magia>();
		
		
		//ACTUALIZAR LA POSICION DE LA CAMARA A LA POSICION DEL HEROE
		//camera.translate(posInicialHeroeX, posInicialHeroeY);
		
		//CREAMOS EL INPUT PROCESOR Y EL CONTROLADOR PARA CONTROLAR EL TECLADO Y EL RATON
		controlador=new ControladorEntrada();
		input=new ProcesadorInput(controlador,this);
		Gdx.input.setInputProcessor(input);
		
		//INDICADORES DE POSICION DEL HEROE Y FRAMES POR SEGUNDO
		indicadorPosicionHeroe = new BitmapFont();
		indicadorFramesPorSegundo = new BitmapFont();
		
		//texturaFondo = new Texture("Captura.png");
		
		//MAPA
		
		//cameraMapa.translate(-Gdx.graphics.getWidth(),-Gdx.graphics.getHeight());
		TmxMapLoader loader = new TmxMapLoader();
		mapa = loader.load("maps/mapa1.tmx");
		mapRenderer = new OrthogonalTiledMapRenderer(mapa); // podemos tambien pasarle un parametro float a este constructor para escalar el mapa 
		mapRenderer.setView(camera);
		
		
		collisionLayer = (TiledMapTileLayer) mapa.getLayers().get(capaQueColisiona);
		//FIN MAPA
	}
	@Override
	public void hide() {
		// TODO Auto-generated method stub
		super.hide();
	}
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		super.dispose();
		heroe.getTextura().dispose();
		indicadorFramesPorSegundo.dispose();
		indicadorPosicionHeroe.dispose();
		heroe.getGraphicsNombre().dispose();
		gestorJugadores.dispose();
		for(int i=0;i<arrayFlechas.size();i++){
			arrayFlechas.get(i).getTextura().dispose();
		}
		for(int i=0;i<arrayFlechas.size();i++){
			arrayMagias.get(i).getTextura().dispose();
		}
			//mapa
		mapa.dispose();
		mapRenderer.dispose();
		//mapa
	}
	@Override
	public void render(float delta) {
		//System.out.println("Renderizando");
		camera.position.set(heroe.getX(),heroe.getY(),0);
		camera.update();
		
		juego.getBatch().setProjectionMatrix(camera.combined);
		shaper.setProjectionMatrix(camera.combined);
		mapRenderer.setView(camera);
		
		renderizar();	
		
		
	}

	
	public void renderizar(){
		
		Gdx.gl.glClearColor(0.2f, 0.4f, 0.2f, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		//pintaFondo();
		
		gestorJugadores.getFlechas((ArrayList<Flecha>) arrayFlechas);
		gestorJugadores.getMagias((ArrayList<Magia>) arrayMagias);
		//PINTAR EL MAPA DE TILES
		mapRenderer.render(new int[] {0});//podemos indicarle a este metodo que capas queremos renderizar,
		//esto es util para que el personaje vaya encima del mapa epro destras de los arboles por ejemplo
		//FIN PINTAR EL MAPA DE TILES
		
		//CODIGO PARA PINTAR HEROE 
		//dibujaAnimacionHeroe();
		
		TextureRegion frameHeroe = heroe.actualizarAnimacion(controlador);
		
		actualizaPosHeroeCamara();
		
		heroe.update(this);
		//FIN CODIGO PARA PINTAR HEROE
		
		
		//CODIGO PARA PINTAR LOS INDICADORES
		int nfps = Math.round(1/Gdx.graphics.getDeltaTime());
		//FIN CODIGO PINTAR INDICADORES
		
		juego.getBatch().begin();
		pintaMagiasAcabadas();
		 juego.getBatch().end();
		calculaNuevaPosicionFlechas();
		calculaColisionMagias();
		//PINTAMOS TODOS LOS OBJETOS QUE HAYA QUE PINTAR
		juego.getBatch().begin();
		//Pintamos las flechas
	//juego.getBatch().draw(texturaFondo, 0, 0);
		pintaFlechas();
		
		indicadorFramesPorSegundo.draw(juego.getBatch(),"FPS: "+nfps,20,20); //INDICADOR FRAMES
		 indicadorPosicionHeroe.draw(juego.getBatch(),"Posicion "+heroe.getX()+","+heroe.getY(), 200, 20); //INDICADOR DE POSICION HEROE
		 juego.getBatch().draw(frameHeroe, (heroe.getX()-heroe.getAnimacion().getAnchoFrame()/2 ), heroe.getY() - (heroe.getAnimacion().getAltoFrame()/2));//HEROE
		 
		 juego.getBatch().end();
		 gestorJugadores.pintaJugadores();
		 gestorJugadores.pintaBarrasVida(shaper);
		 pintaNombreHeroe();
		 pintaVidaHeroe();
		 juego.getBatch().begin();
		 pintaMagias();
		 juego.getBatch().end();
		//FIN DE PINTAMOS TODOS LOS OBJETOS QUE HAYA QUE PINTAR
		 mapRenderer.render(new int[] {1});
		
		
		 
		 pintaEjes();
		 juego.getCliente().enviarActualizacion(heroe.getSerializada());
		
		
	}
	
	private void pintaVidaHeroe() {
		// TODO Auto-generated method stub
		BarraVida.dibujarNuevaBarra(heroe.getX(), heroe.getY(), heroe.getVida(), shaper);
	}

	private void calculaColisionMagias() {
		// TODO Auto-generated method stub
		for (int i = 0; i < arrayMagias.size(); i++) {
			Magia magia = arrayMagias.get(i);

			if (magia.getEstado() == Magia.estadoProceso) {

				if (magia.isFrameDamage()) {
					if(heroe.getRectangle().overlaps(magia.getRectangle())){
						heroe.recibirMagia(magia);
						magia.setEstado(Magia.estadoFinished);
					}
				}
			}

			else { // estado finiquitao
				magia.actualizarContador(Gdx.graphics.getDeltaTime());
				if (arrayMagias.get(i).getContador() >= 2) {
					arrayMagias.remove(i);
					i--;
				}
			}
		}

	}

	public void calculaNuevaPosicionFlechas(){//metodo editado para debug mirar comentarios 
		for(int i = 0; i < arrayFlechas.size(); i++){
			if(arrayFlechas.get(i).getEstado() == Flecha.estadoVolando){
				arrayFlechas.get(i).calcularNuevaPosicion(gestorJugadores);
			}else if(arrayFlechas.get(i).getEstado() == Flecha.estadoChocaHeroe) {
				arrayFlechas.remove(i);
				i--;
			}else{//flecha parada
				if(arrayFlechas.get(i).getContador()>= 2){
					arrayFlechas.remove(i);
					i--;
				}else{
					arrayFlechas.get(i).actualizarContador(Gdx.graphics.getDeltaTime());
				}
			//	System.out.println("posicion flechas "+arrayFlechas.get(i).getX()+","+arrayFlechas.get(i).getX());
				
			//	arrayFlechas.remove(i);
				
			//	System.out.println("flecha borrada, numero de flechas =" + arrayFlechas.size());
				
				//if(i!=(arrayFlechas.size()-1))i--;
			}
		}
	}
	public void pintaEjes(){
		shaper.begin(ShapeType.Line);
		shaper.line(-10000, 0, 10000,0);
		shaper.line(0, -10000,0,10000);
		for(int i = -10000; i<= 10000; i+=32){
			shaper.line(-10, i,10,i);
			shaper.line(i,-10,i,10);
			
		}
		shaper.end();
	}
	public void pintaFlechas(){
		
		for(int i=0;i<arrayFlechas.size();i++){
			
			arrayFlechas.get(i).getSprite().draw(juego.getBatch());
			//arrayFlechas.get(i).getSprite().rotate(1);
		//	juego.getBatch().draw(arrayFlechas.get(i).getSprite(), arrayFlechas.get(i).getX(), arrayFlechas.get(i).getY());
		}
		
		
	}
	
	/**
	 * Necesita que el batch este begineado
	 * */
	public void pintaMagias(){
		for(int i=0;i<arrayMagias.size();i++){
			
			Magia magia = arrayMagias.get(i);
			if(magia.getEstado() == Magia.estadoProceso)
				juego.getBatch().draw(magia.getFrameActual(), (magia.getX()-(magia.getAnchoFrame()/2) ), magia.getY() - (magia.getAltoFrame()/2));
			//System.out.println(i);
			//System.out.println( magia.getX()+" "+ magia.getY());
		}
	}
	public void pintaMagiasAcabadas(){
	for(int i=0;i<arrayMagias.size();i++){
			
			Magia magia = arrayMagias.get(i);
			if(magia.getEstado() == Magia.estadoFinished)
				juego.getBatch().draw(magia.getFrameActual(), (magia.getX()-(magia.getAnchoFrame()/2) ), magia.getY() - (magia.getAltoFrame()/2));
			//System.out.println(i);
			//System.out.println( magia.getX()+" "+ magia.getY());
		}
	}
	
	public void pintaNombreHeroe(){
		
		juego.getBatch().begin();
		heroe.getGraphicsNombre().draw(juego.getBatch(),heroe.getNombre(), (heroe.getX()-heroe.getAnimacion().getAnchoFrame()/2 )+16, heroe.getY() - (heroe.getAnimacion().getAltoFrame()/2)+83); // mostrar nombre personaje encima de este.
		juego.getBatch().end();
	}
	
	
	/**
	 * Actualiza posicion del heroe y de las camaras tanto del heroe como del mapa
	 * */
	public void actualizaPosHeroeCamara() {

		if(!heroe.isDead()){
		float delta = Gdx.graphics.getDeltaTime();
		float velocidad = heroe.getVelocidadMovimiento();
		
		boolean collisionX = false;
		boolean collisionY = false;
		
		
		float x = heroe.getX();
		float y = heroe.getY();
		
		
		
		if (controlador.getMoverIzquierda()) {
			
			float incrementoIzq = velocidad * delta;
			x = x - incrementoIzq;

			if (!colisionaIzquierda(x, y)) {
				
				heroe.setPos(x, y);
				//camera.translate(-incrementoIzq, 0);
			}

		}
		if (controlador.getMoverDerecha()) {
			
			float incrementoDer = velocidad * delta;
			x = x + incrementoDer;
			
			if (!colisionaDerecha(x, y)) {
				heroe.setPos(x, y);
				//camera.translate(incrementoDer, 0);
			}
		}
		if (controlador.getMoverArriba()) {
			
			float incrementoArr = velocidad * delta;
			y = y + incrementoArr;
			
			if (!colisionaArriba(x, y)) {
				heroe.setPos(x, y);
				//camera.translate(0, incrementoArr);
			}
		}
		if (controlador.getMoverAbajo()) {
			
			float incrementoAbaj = velocidad * delta;
			y = y - incrementoAbaj;
			
			if (!colisionaAbajo(x, y)) {
				heroe.setPos(x, y);
				//camera.translate(0,-incrementoAbaj);
			}
		}
	}
		
	}
	public void addFlecha(Flecha flecha) {
		arrayFlechas.add(flecha);
		//System.out.println("Flecha a\F1adida");
	}
	public void addMagia(Magia magia){
		arrayMagias.add(magia);
	}
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		camera.setToOrtho(false, width, height);
	}
	public OrthographicCamera getCamera(){
		return camera;
	}
	public Heroe getHeroe(){
		return heroe;
	}
	
	/**
	 * Comprobamos la posicion izquierda-arriba izquierda-medio izquierda-abajo
	 * La palabra clave para saber si bloquea es blocked
	 * */
	
	public boolean colisionaIzquierda(float x,float y){
		float tileWidth = collisionLayer.getTileWidth(), tileHeight = collisionLayer.getTileHeight();
		boolean colisiona =  gestorJugadores.getNextColisiona(x,y);
		
		try{
        	if(collisionLayer.getCell((int)((x - heroe.getAnchoReal()/2) / tileWidth) , 
        			(int) (y /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//System.out.println("blocked");
        		colisiona = true;
        	}
				
        	}catch(Exception ex){
        		//System.err.println("null cell");
        	}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x - heroe.getAnchoReal()/2) / tileWidth) , 
	        			(int) ((y - heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
					//System.out.println("blocked");
					//System.out.println("choca izq abajo");
	        		colisiona = true;
	        		
	        	}
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x - heroe.getAnchoReal()/2) / tileWidth) ,
	        			(int) ((y + heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
					//System.out.println("blocked");
	        		colisiona = true;
	        	}
					
	        	}catch(Exception ex){
	        		//System.err.println("null cell");
	        	}
		}
		return colisiona;
		
	}
	
	/**
	 * Comprobamos la posicion derecha-arriba derecha-medio derecha-abajo
	 * La palabra clave para saber si bloquea es blocked
	 * */
	public boolean colisionaDerecha(float x,float y){
		float tileWidth = collisionLayer.getTileWidth(), tileHeight = collisionLayer.getTileHeight();
		boolean colisiona =  gestorJugadores.getNextColisiona(x,y);
		
		try{
        	if(collisionLayer.getCell((int)((x + heroe.getAnchoReal()/2) / tileWidth) ,
        			(int) (y /tileHeight)).getTile().getProperties().containsKey("blocked")){
			//	System.out.println("blocked");
        		colisiona = true;
        		
        	}
        	}catch(Exception ex){
        	//	System.err.println("null cell");
        	}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x + heroe.getAnchoReal()/2) / tileWidth) , 
	        			(int) ((y - heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//	System.out.println("blocked");
	        		colisiona = true;
	        		
	        	}
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x + heroe.getAnchoReal()/2) / tileWidth) , 
	        			(int) ((y + heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//	System.out.println("blocked");
	        		colisiona = true;
	        		
			}
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		return colisiona;
		
	}
	
	/**
	 * Comprobamos la posicion arriba-derecha arriba-medio arriba-izquierda
	 * La palabra clave para saber si bloquea es blocked
	 * */
	public boolean colisionaArriba(float x,float y){
		float tileWidth = collisionLayer.getTileWidth(), tileHeight = collisionLayer.getTileHeight();
		boolean colisiona =  gestorJugadores.getNextColisiona(x,y);

		
		
		try{
			
        	if(collisionLayer.getCell((int)((x - heroe.getAnchoReal()/2) / tileWidth) , 
        			(int) ((y + heroe.getAltoReal()/2) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//System.out.println("blocked");
        		colisiona = true;
        		
        	}
        	}catch(Exception ex){
        	//	System.err.println("null cell");
        	}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)(x  / tileWidth) ,
	        			(int) ((y + heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//	System.out.println("blocked");
	        		colisiona = true;
	        	}
					
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x + heroe.getAnchoReal()/2) / tileWidth) ,
	        			(int) ((y + heroe.getAltoReal() / 2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//	System.out.println("blocked");
	        		colisiona = true;
	        		
	        	}
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		return colisiona;
		
	}
	public boolean colisionaXY(float x, float y){
		float tileWidth = collisionLayer.getTileWidth(), tileHeight = collisionLayer.getTileHeight();
		//boolean colisiona =  gestorJugadores.getNextColisiona(x,y);
		boolean colisiona;
		try{
		 colisiona = collisionLayer.getCell((int)(x / tileWidth) ,
    			(int) (y /tileHeight)).getTile().getProperties().containsKey("blocked");
		System.out.println("blocked");
		}catch(Exception ex){
			colisiona = false;
		}
		return colisiona;
	}
	/**
	 * Comprobamos la posicion abajo-derecha abajo-medio abajo-izquierda
	 * La palabra clave para saber si bloquea es blocked
	 * */
	public boolean colisionaAbajo(float x,float y){
		float tileWidth = collisionLayer.getTileWidth(), tileHeight = collisionLayer.getTileHeight();
		boolean colisiona =  gestorJugadores.getNextColisiona(x,y);
		
		try{
			
        	if(collisionLayer.getCell((int)((x - heroe.getAnchoReal()/2) / tileWidth) ,
        			(int) ((y - heroe.getAltoReal()/2) /tileHeight)).getTile().getProperties().containsKey("blocked")){
			//	System.out.println("blocked");
        		colisiona = true;
        		
        	}
        	}catch(Exception ex){
        	//	System.err.println("null cell");
        	}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)(x  / tileWidth) ,
	        			(int) ((y - heroe.getAltoReal()/2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
				//	System.out.println("blocked");
	        		colisiona = true;
	        		
	        	}
	        	}catch(Exception ex){
	        	//	System.err.println("null cell");
	        	}
		}
		
		if(!colisiona){
			try{
	        	if(collisionLayer.getCell((int)((x + heroe.getAnchoReal()/2) / tileWidth) , 
	        			(int) ((y - heroe.getAltoReal() / 2 ) /tileHeight)).getTile().getProperties().containsKey("blocked")){
			//		System.out.println("blocked");
	        		colisiona = true;
	        		
	        	}
	        	}catch(Exception ex){
	        //		System.err.println("null cell");
	        	}
		}
		return colisiona;
		
	}
	public TiledMapTileLayer getCollisionLayer(){
		return collisionLayer;
	}
	
	public GestorJugadoresVirtuales getGestorUsuarios(){
		return gestorJugadores;
	}
	
}