package Larguia;
/*
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javazoom.jl.decoder.JavaLayerException;
import javazoom.jl.player.advanced.AdvancedPlayer;
*/
public class ControladorSonido {
	/*
	public static boolean sonidoActivado = true;
	
	public static void sonidoDispararFlecha(){
		
		AdvancedPlayer reproductor;
		//JFileChooser seleccionador = new JFileChooser();
		//int a = seleccionador.showOpenDialog(null);
		File archivo = new File("disparo.mp3");
		try {
			reproductor = new AdvancedPlayer(new FileInputStream(archivo));
			reproductor.play();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JavaLayerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
}
