package Larguia;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;

public class Fisica {
	public static final int VELOCITYITERATIONS = 6; //MIRAR DOCUMENTACION DE BOX2D
	public static final int POSITIONITERATIONS = 2;
	protected World world;
	protected Box2DDebugRenderer debugRenderer;
	protected BodyDef bodyDef;
	public Fisica(){
		world = new World(new Vector2(0,0),true);
		debugRenderer = new Box2DDebugRenderer();
	}
	public void addObjects(){
		bodyDef = new BodyDef();
	//	PolygonShape heroe = new PolygonShape(
	}
	public void stepWorld(float delta){
	
		world.step(delta, VELOCITYITERATIONS, POSITIONITERATIONS);
	}
	public void render(OrthographicCamera camera){
		debugRenderer.render(world, camera.combined);
	}
}