package Larguia;

import com.badlogic.gdx.Screen;

public abstract class Pantalla implements Screen {
	
	protected Juego juego;
	public Pantalla(Juego juego){
		this.juego=juego;
	}
	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}
	public Juego getJuego(){
		return juego;
	}
	@Override
	public void render(float delta) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		
	}
	
}