package Auxiliar;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;

public class Colisiones {

	World world;
	Box2DDebugRenderer debugRenderer;
	private float accumulator = 0;

	
	public Colisiones(){
		world = new World(new Vector2(0,0),true);
		debugRenderer = new Box2DDebugRenderer();
		
		
	}
	
	public void render(){
		// en esta parte lo que vamos a hacer es lo que hariamos al final del render para actualizar nuestro mapa
		world.step(1/60f, 6, 2); //cambiar 60f por el resultado que muestra en el indicador frames/seg 
	}
	/**private void doPhysicsStep(float deltaTime) {
	    // fixed time step
	    // max frame time to avoid spiral of death (on slow devices)
	    float frameTime = Math.min(deltaTime, 0.25f);
	    accumulator += frameTime;
	    while (accumulator >= Constants.TIME_STEP) {
	        WorldManager.world.step(Constants.TIME_STEP, Constants.VELOCITY_ITERATIONS, Constants.POSITION_ITERATIONS);
	        accumulator -= Constants.TIME_STEP;
	    }
	}*/
}
